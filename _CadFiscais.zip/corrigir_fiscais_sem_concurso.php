<?php
require_once 'config.php';

// Verificar se o usuário está logado
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuário não está logado']);
    exit;
}

$db = getDB();

try {
    // Buscar o primeiro concurso ativo
    $stmt = $db->query("SELECT id FROM concursos WHERE status = 'ativo' ORDER BY id ASC LIMIT 1");
    $concurso = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$concurso) {
        echo json_encode(['success' => false, 'message' => 'Nenhum concurso ativo encontrado']);
        exit;
    }
    
    $concurso_id = $concurso['id'];
    
    // Atualizar fiscais sem concurso
    $stmt = $db->prepare("
        UPDATE fiscais 
        SET concurso_id = ? 
        WHERE concurso_id IS NULL OR concurso_id = 0
    ");
    $stmt->execute([$concurso_id]);
    
    $fiscais_atualizados = $stmt->rowCount();
    
    echo json_encode([
        'success' => true, 
        'message' => "{$fiscais_atualizados} fiscais foram atualizados com o concurso ID {$concurso_id}"
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?> 