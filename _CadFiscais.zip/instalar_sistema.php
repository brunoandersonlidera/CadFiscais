<?php
require_once 'config.php';

echo "<h1>🚀 Instalação Completa do Sistema IDH</h1>";
echo "<p>Este script irá configurar todas as tabelas e funcionalidades do sistema.</p>";

try {
    $db = getDB();
    
    if (!$db) {
        throw new Exception("Não foi possível conectar ao banco de dados");
    }
    
    echo "<h2>✅ Conexão com banco de dados estabelecida</h2>";
    
    // 1. Verificar e corrigir tabela de usuários
    echo "<h3>1. Configurando tabela de usuários...</h3>";
    include 'corrigir_tabela_usuarios.php';
    
    echo "<hr>";
    
    // 2. Verificar e corrigir tabela de fiscais
    echo "<h3>2. Configurando tabela de fiscais...</h3>";
    include 'corrigir_tabela_fiscais.php';
    
    echo "<hr>";
    
    // 3. Verificar e corrigir tabela de concursos
    echo "<h3>3. Configurando tabela de concursos...</h3>";
    include 'corrigir_cadastro.php';
    
    echo "<hr>";
    
    // 4. Criar tabela de presença
    echo "<h3>4. Criando tabela de presença de fiscais...</h3>";
    include 'criar_tabela_presenca.php';
    
    echo "<hr>";
    
    // 5. Criar tabela de pagamentos
    echo "<h3>5. Criando tabela de pagamentos de fiscais...</h3>";
    include 'criar_tabela_pagamentos.php';
    
    echo "<hr>";
    
    // 6. Verificar configurações
    echo "<h3>6. Verificando configurações do sistema...</h3>";
    
    $stmt = $db->query("SELECT chave, valor FROM configuracoes WHERE chave = 'cadastro_aberto'");
    $config = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$config) {
        echo "<p>Configurando cadastro como aberto...</p>";
        $stmt = $db->prepare("INSERT INTO configuracoes (chave, valor) VALUES ('cadastro_aberto', '1')");
        $stmt->execute();
        echo "<p>✅ Cadastro configurado como aberto</p>";
    } else {
        echo "<p>✅ Configuração de cadastro já existe</p>";
    }
    
    // 7. Verificar se existe usuário administrador
    echo "<h3>7. Verificando usuário administrador...</h3>";
    
    $stmt = $db->query("SELECT COUNT(*) FROM usuarios WHERE tipo_usuario = 'administrador'");
    $admin_count = $stmt->fetchColumn();
    
    if ($admin_count == 0) {
        echo "<p>Criando usuário administrador padrão...</p>";
        
        $senha_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $db->prepare("
            INSERT INTO usuarios (nome, email, senha, tipo_usuario, status, created_at) 
            VALUES ('Administrador', 'admin@idh.com', ?, 'administrador', 'ativo', CURRENT_TIMESTAMP)
        ");
        $stmt->execute([$senha_hash]);
        
        echo "<p>✅ Usuário administrador criado:</p>";
        echo "<ul>";
        echo "<li><strong>Email:</strong> admin@idh.com</li>";
        echo "<li><strong>Senha:</strong> admin123</li>";
        echo "<li><strong>Tipo:</strong> Administrador</li>";
        echo "</ul>";
    } else {
        echo "<p>✅ Usuário administrador já existe</p>";
    }
    
    // 8. Verificar estrutura de concursos
    echo "<h3>8. Verificando estrutura de concursos...</h3>";
    
    $stmt = $db->query("DESCRIBE concursos");
    $campos_concursos = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $campos_concursos[] = $row['Field'];
    }
    
    $campos_necessarios_concursos = [
        'valor_pagamento' => "DECIMAL(10,2) DEFAULT 0.00",
        'termos_aceite' => "TEXT",
        'status' => "ENUM('ativo', 'inativo', 'cancelado') DEFAULT 'ativo'"
    ];
    
    foreach ($campos_necessarios_concursos as $campo => $tipo) {
        if (!in_array($campo, $campos_concursos)) {
            echo "<p>Adicionando campo '$campo' à tabela concursos...</p>";
            $sql = "ALTER TABLE concursos ADD COLUMN $campo $tipo";
            $db->exec($sql);
            echo "<p>✅ Campo '$campo' adicionado</p>";
        } else {
            echo "<p>✅ Campo '$campo' já existe</p>";
        }
    }
    
    echo "<hr>";
    
    // 9. Resumo final
    echo "<h2>🎉 Instalação Concluída com Sucesso!</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px; padding: 15px; margin: 20px 0;'>";
    echo "<h4>✅ Sistema configurado com as seguintes funcionalidades:</h4>";
    echo "<ul>";
    echo "<li>📝 Cadastro de fiscais com auditoria completa</li>";
    echo "<li>📊 Sistema de relatórios em PDF</li>";
    echo "<li>📱 Controle de presença mobile</li>";
    echo "<li>💰 Controle de pagamentos</li>";
    echo "<li>⚙️ Painel administrativo</li>";
    echo "<li>🔒 Sistema de autenticação</li>";
    echo "<li>📋 Aceite de termos com registro de data/hora</li>";
    echo "<li>🌐 Interface responsiva</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 5px; padding: 15px; margin: 20px 0;'>";
    echo "<h4>⚠️ Próximos passos:</h4>";
    echo "<ol>";
    echo "<li>Acesse o <a href='admin/login.php'>painel administrativo</a></li>";
    echo "<li>Faça login com: admin@idh.com / admin123</li>";
    echo "<li>Configure os concursos ativos</li>";
    echo "<li>Teste o cadastro de fiscais</li>";
    echo "<li>Use as ferramentas de controle de presença e pagamentos</li>";
    echo "</ol>";
    echo "</div>";
    
    echo "<div style='background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 5px; padding: 15px; margin: 20px 0;'>";
    echo "<h4>🔧 Ferramentas disponíveis:</h4>";
    echo "<ul>";
    echo "<li><a href='relatorios.php'>📊 Relatórios</a> - Geração de relatórios em PDF</li>";
    echo "<li><a href='presenca_mobile.php'>📱 Controle de Presença</a> - Para uso em celular</li>";
    echo "<li><a href='pagamentos.php'>💰 Controle de Pagamentos</a> - Gestão financeira</li>";
    echo "<li><a href='admin/dashboard.php'>⚙️ Painel Admin</a> - Configurações gerais</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; padding: 15px; margin: 20px 0;'>";
    echo "<h4>❌ Erro durante a instalação:</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<br><a href='index.php' class='btn btn-primary'>🏠 Voltar ao Sistema</a>";
?> 