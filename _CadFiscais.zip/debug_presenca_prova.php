<?php
require_once 'config.php';

echo "<h1>🔍 Debug - Presença na Prova</h1>";

$db = getDB();

// Parâmetros da URL
$concurso_id = isset($_GET['concurso_id']) ? (int)$_GET['concurso_id'] : 9;
$escola_id = isset($_GET['escola_id']) ? (int)$_GET['escola_id'] : 30;

echo "<h2>Parâmetros:</h2>";
echo "Concurso ID: {$concurso_id}<br>";
echo "Escola ID: {$escola_id}<br>";

// Verificar se o concurso existe
echo "<h2>1. Verificar Concurso</h2>";
try {
    $stmt = $db->prepare("SELECT * FROM concursos WHERE id = ?");
    $stmt->execute([$concurso_id]);
    $concurso = $stmt->fetch();
    
    if ($concurso) {
        echo "✅ Concurso encontrado: {$concurso['titulo']}<br>";
    } else {
        echo "❌ Concurso não encontrado<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}

// Verificar se a escola existe
echo "<h2>2. Verificar Escola</h2>";
try {
    $stmt = $db->prepare("SELECT * FROM escolas WHERE id = ? AND concurso_id = ?");
    $stmt->execute([$escola_id, $concurso_id]);
    $escola = $stmt->fetch();
    
    if ($escola) {
        echo "✅ Escola encontrada: {$escola['nome']}<br>";
    } else {
        echo "❌ Escola não encontrada<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}

// Verificar fiscais aprovados do concurso
echo "<h2>3. Fiscais Aprovados do Concurso</h2>";
try {
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM fiscais WHERE concurso_id = ? AND status = 'aprovado'");
    $stmt->execute([$concurso_id]);
    $total_fiscais = $stmt->fetchColumn();
    echo "Total de fiscais aprovados: {$total_fiscais}<br>";
    
    $stmt = $db->prepare("SELECT id, nome FROM fiscais WHERE concurso_id = ? AND status = 'aprovado' LIMIT 5");
    $stmt->execute([$concurso_id]);
    $fiscais = $stmt->fetchAll();
    
    echo "Primeiros 5 fiscais:<br>";
    foreach ($fiscais as $fiscal) {
        echo "- ID: {$fiscal['id']}, Nome: {$fiscal['nome']}<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}

// Verificar alocações da escola
echo "<h2>4. Alocações da Escola</h2>";
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as total 
        FROM alocacoes_fiscais af
        INNER JOIN fiscais f ON af.fiscal_id = f.id
        WHERE af.escola_id = ? AND af.status = 'ativo' AND f.concurso_id = ?
    ");
    $stmt->execute([$escola_id, $concurso_id]);
    $total_alocacoes = $stmt->fetchColumn();
    echo "Total de alocações na escola: {$total_alocacoes}<br>";
    
    $stmt = $db->prepare("
        SELECT af.*, f.nome as fiscal_nome, e.nome as escola_nome, s.nome as sala_nome
        FROM alocacoes_fiscais af
        INNER JOIN fiscais f ON af.fiscal_id = f.id
        LEFT JOIN escolas e ON af.escola_id = e.id
        LEFT JOIN salas s ON af.sala_id = s.id
        WHERE af.escola_id = ? AND af.status = 'ativo' AND f.concurso_id = ?
        ORDER BY f.nome
        LIMIT 5
    ");
    $stmt->execute([$escola_id, $concurso_id]);
    $alocacoes = $stmt->fetchAll();
    
    echo "Primeiras 5 alocações:<br>";
    foreach ($alocacoes as $alocacao) {
        echo "- Fiscal: {$alocacao['fiscal_nome']}, Escola: {$alocacao['escola_nome']}, Sala: {$alocacao['sala_nome']}<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}

// Testar consulta completa
echo "<h2>5. Consulta Completa (como no arquivo original)</h2>";
try {
    $where_conditions = ["f.concurso_id = ?", "f.status = 'aprovado'"];
    $params = [$concurso_id];
    
    if ($escola_id) {
        $where_conditions[] = "af.escola_id = ?";
        $params[] = $escola_id;
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    
    $sql = "
        SELECT f.*, 
               e.nome as escola_nome,
               s.nome as sala_nome,
               af.tipo_alocacao,
               af.observacoes as observacoes_alocacao,
               af.id as alocacao_id,
               af.escola_id,
               af.sala_id,
               CASE WHEN pf.presente IS NOT NULL THEN pf.presente ELSE NULL END as presenca_registrada,
               pf.observacoes as observacoes_presenca,
               pf.created_at as data_registro_presenca
        FROM fiscais f
        INNER JOIN alocacoes_fiscais af ON f.id = af.fiscal_id AND af.status = 'ativo'
        LEFT JOIN escolas e ON af.escola_id = e.id
        LEFT JOIN salas s ON af.sala_id = s.id
        LEFT JOIN presenca_fiscais pf ON f.id = pf.fiscal_id AND pf.concurso_id = f.concurso_id
        WHERE $where_clause
        ORDER BY e.nome, s.nome, f.nome
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll();
    
    echo "Resultados da consulta completa: " . count($resultados) . " fiscais<br>";
    
    if (!empty($resultados)) {
        echo "Primeiros 3 resultados:<br>";
        foreach (array_slice($resultados, 0, 3) as $resultado) {
            echo "- Fiscal: {$resultado['nome']}, Escola: {$resultado['escola_nome']}, Sala: {$resultado['sala_nome']}<br>";
        }
    } else {
        echo "❌ Nenhum resultado encontrado<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro na consulta: " . $e->getMessage() . "<br>";
}

echo "<br><a href='presenca_prova.php?concurso_id={$concurso_id}&escola_id={$escola_id}'>Testar Presença na Prova</a>";
?> 