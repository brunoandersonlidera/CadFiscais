<?php
require_once 'config.php';
require_once 'ddi.php';

// Habilitar exibição de erros
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 Debug do Cadastro</h1>";

// Verificar conexão com banco
echo "<h2>1. Verificação de Conexão</h2>";
$db = getDB();
if ($db) {
    echo "✅ Conexão com banco OK<br>";
} else {
    echo "❌ Erro na conexão com banco<br>";
    exit;
}

// Verificar estrutura da tabela fiscais
echo "<h2>2. Estrutura da Tabela Fiscais</h2>";
try {
    $stmt = $db->query("DESCRIBE fiscais");
    $colunas = $stmt->fetchAll();
    echo "<table border='1'>";
    echo "<tr><th>Coluna</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th></tr>";
    foreach ($colunas as $coluna) {
        echo "<tr>";
        echo "<td>" . $coluna['Field'] . "</td>";
        echo "<td>" . $coluna['Type'] . "</td>";
        echo "<td>" . $coluna['Null'] . "</td>";
        echo "<td>" . $coluna['Key'] . "</td>";
        echo "<td>" . ($coluna['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "❌ Erro ao verificar estrutura: " . $e->getMessage() . "<br>";
}

// Verificar concursos
echo "<h2>3. Concursos Disponíveis</h2>";
try {
    $stmt = $db->query("SELECT * FROM concursos WHERE status = 'ativo'");
    $concursos = $stmt->fetchAll();
    echo "Concursos ativos: " . count($concursos) . "<br>";
    foreach ($concursos as $concurso) {
        echo "- ID: {$concurso['id']}, Título: {$concurso['titulo']}<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao buscar concursos: " . $e->getMessage() . "<br>";
}

// Teste de inserção
echo "<h2>4. Teste de Inserção</h2>";
try {
    // Dados de teste
    $dados_teste = [
        'concurso_id' => 2, // Concurso que você está testando
        'nome' => 'Teste Debug',
        'email' => 'teste@debug.com',
        'ddi' => '+55',
        'celular' => '(11) 99999-9999',
        'whatsapp' => '',
        'cpf' => '12345678901',
        'data_nascimento' => '1990-01-01',
        'genero' => 'M',
        'endereco' => 'Rua Teste, 123',
        'melhor_horario' => 'manha',
        'observacoes' => 'Teste de debug',
        'status' => 'pendente',
        'status_contato' => 'nao_contatado',
        'aceite_termos' => 1,
        'data_aceite_termos' => date('Y-m-d H:i:s'),
        'ip_cadastro' => '127.0.0.1',
        'user_agent' => 'Debug Script'
    ];
    
    echo "Tentando inserir dados de teste...<br>";
    
    // Verificar se a função insertFiscal existe
    if (function_exists('insertFiscal')) {
        echo "✅ Função insertFiscal existe<br>";
        
        // Tentar inserção
        $fiscal_id = insertFiscal($dados_teste);
        
        if ($fiscal_id) {
            echo "✅ Inserção bem-sucedida! ID: $fiscal_id<br>";
            
            // Verificar se foi realmente inserido
            $stmt = $db->prepare("SELECT * FROM fiscais WHERE id = ?");
            $stmt->execute([$fiscal_id]);
            $fiscal = $stmt->fetch();
            
            if ($fiscal) {
                echo "✅ Fiscal encontrado no banco:<br>";
                echo "- Nome: {$fiscal['nome']}<br>";
                echo "- Email: {$fiscal['email']}<br>";
                echo "- CPF: {$fiscal['cpf']}<br>";
                echo "- Status: {$fiscal['status']}<br>";
            } else {
                echo "❌ Fiscal não encontrado após inserção<br>";
            }
        } else {
            echo "❌ Erro na inserção - retornou false/null<br>";
        }
    } else {
        echo "❌ Função insertFiscal não existe<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro no teste de inserção: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
}

// Verificar logs
echo "<h2>5. Logs do Sistema</h2>";
$log_file = 'logs/system.log';
if (file_exists($log_file)) {
    echo "Últimas 10 linhas do log:<br>";
    $lines = file($log_file);
    $last_lines = array_slice($lines, -10);
    foreach ($last_lines as $line) {
        echo htmlspecialchars($line) . "<br>";
    }
} else {
    echo "❌ Arquivo de log não encontrado<br>";
}

// Verificar configurações
echo "<h2>6. Configurações do Sistema</h2>";
echo "Cadastro aberto: " . getConfig('cadastro_aberto', 'não definido') . "<br>";
echo "Idade mínima: " . getConfig('idade_minima', 'não definido') . "<br>";
echo "DDI padrão: " . getConfig('ddi_padrao', 'não definido') . "<br>";

// Verificar permissões de arquivo
echo "<h2>7. Permissões de Arquivo</h2>";
$files_to_check = [
    'processar_cadastro.php',
    'config.php',
    'ddi.php',
    'logs/',
    'data/'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        $perms = fileperms($file);
        $readable = is_readable($file);
        $writable = is_writable($file);
        echo "$file: " . ($readable ? "✅" : "❌") . " leitura, " . ($writable ? "✅" : "❌") . " escrita<br>";
    } else {
        echo "$file: ❌ não existe<br>";
    }
}

echo "<h2>8. Informações do PHP</h2>";
echo "PHP Version: " . phpversion() . "<br>";
echo "MySQL Extension: " . (extension_loaded('pdo_mysql') ? "✅ Ativo" : "❌ Inativo") . "<br>";
echo "Error Reporting: " . error_reporting() . "<br>";
echo "Display Errors: " . (ini_get('display_errors') ? "On" : "Off") . "<br>";

echo "<h2>9. Teste de Funções</h2>";
echo "getDB(): " . (function_exists('getDB') ? "✅ Existe" : "❌ Não existe") . "<br>";
echo "getConfig(): " . (function_exists('getConfig') ? "✅ Existe" : "❌ Não existe") . "<br>";
echo "logActivity(): " . (function_exists('logActivity') ? "✅ Existe" : "❌ Não existe") . "<br>";
echo "validateDDI(): " . (function_exists('validateDDI') ? "✅ Existe" : "❌ Não existe") . "<br>";

echo "<hr>";
echo "<h3>🔧 Ações</h3>";
echo "<a href='atualizar_tabela_fiscais.php' class='btn btn-warning'>Atualizar Tabela</a> ";
echo "<a href='cadastro_fixo.php?concurso=2' class='btn btn-primary'>Testar Cadastro</a> ";
echo "<a href='admin/' class='btn btn-secondary'>Painel Admin</a>";
?> 