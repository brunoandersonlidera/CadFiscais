<?php
require_once 'config.php';

echo "<h1>🔧 Atualização da Tabela Fiscais</h1>";

$db = getDB();
if (!$db) {
    echo "❌ Erro na conexão com banco<br>";
    exit;
}

// Estrutura completa da tabela fiscais
$colunas_necessarias = [
    'id' => 'INT AUTO_INCREMENT PRIMARY KEY',
    'concurso_id' => 'INT NOT NULL',
    'nome' => 'VARCHAR(255) NOT NULL',
    'email' => 'VARCHAR(255) NOT NULL',
    'ddi' => 'VARCHAR(10) NOT NULL',
    'celular' => 'VARCHAR(20) NOT NULL',
    'whatsapp' => 'VARCHAR(20)',
    'cpf' => 'VARCHAR(14) NOT NULL',
    'data_nascimento' => 'DATE NOT NULL',
    'genero' => 'ENUM("M", "F") NOT NULL',
    'endereco' => 'TEXT NOT NULL',
    'melhor_horario' => 'VARCHAR(50)',
    'observacoes' => 'TEXT',
    'status' => 'ENUM("pendente", "aprovado", "reprovado", "cancelado") DEFAULT "pendente"',
    'status_contato' => 'ENUM("nao_contatado", "contatado", "confirmado", "desistiu") DEFAULT "nao_contatado"',
    'aceite_termos' => 'TINYINT(1) DEFAULT 0',
    'data_aceite_termos' => 'DATETIME',
    'ip_cadastro' => 'VARCHAR(45)',
    'user_agent' => 'TEXT',
    'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
    'updated_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
];

try {
    // Verificar se a tabela existe
    $stmt = $db->query("SHOW TABLES LIKE 'fiscais'");
    $tabela_existe = $stmt->rowCount() > 0;
    
    if (!$tabela_existe) {
        echo "📋 Criando tabela fiscais...<br>";
        
        $sql = "CREATE TABLE fiscais (";
        $colunas = [];
        foreach ($colunas_necessarias as $coluna => $definicao) {
            $colunas[] = "$coluna $definicao";
        }
        $sql .= implode(", ", $colunas);
        $sql .= ")";
        
        $db->exec($sql);
        echo "✅ Tabela fiscais criada com sucesso!<br>";
    } else {
        echo "✅ Tabela fiscais já existe<br>";
        
        // Verificar colunas existentes
        $stmt = $db->query("DESCRIBE fiscais");
        $colunas_existentes = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "📋 Verificando colunas...<br>";
        
        foreach ($colunas_necessarias as $coluna => $definicao) {
            if (!in_array($coluna, $colunas_existentes)) {
                echo "➕ Adicionando coluna: $coluna<br>";
                $sql = "ALTER TABLE fiscais ADD COLUMN $coluna $definicao";
                $db->exec($sql);
                echo "✅ Coluna $coluna adicionada<br>";
            } else {
                echo "✅ Coluna $coluna já existe<br>";
            }
        }
    }
    
    // Criar índices importantes
    echo "📋 Criando índices...<br>";
    
    $indices = [
        'idx_concurso_id' => 'concurso_id',
        'idx_cpf' => 'cpf',
        'idx_email' => 'email',
        'idx_status' => 'status',
        'idx_created_at' => 'created_at'
    ];
    
    foreach ($indices as $nome_indice => $coluna) {
        try {
            $sql = "CREATE INDEX $nome_indice ON fiscais ($coluna)";
            $db->exec($sql);
            echo "✅ Índice $nome_indice criado<br>";
        } catch (Exception $e) {
            echo "ℹ️ Índice $nome_indice já existe ou erro: " . $e->getMessage() . "<br>";
        }
    }
    
    // Verificar estrutura final
    echo "<h2>📊 Estrutura Final da Tabela</h2>";
    $stmt = $db->query("DESCRIBE fiscais");
    $colunas = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background-color: #f0f0f0;'>";
    echo "<th>Coluna</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th><th>Extra</th>";
    echo "</tr>";
    
    foreach ($colunas as $coluna) {
        echo "<tr>";
        echo "<td>" . $coluna['Field'] . "</td>";
        echo "<td>" . $coluna['Type'] . "</td>";
        echo "<td>" . $coluna['Null'] . "</td>";
        echo "<td>" . $coluna['Key'] . "</td>";
        echo "<td>" . ($coluna['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . ($coluna['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Verificar dados existentes
    $stmt = $db->query("SELECT COUNT(*) as total FROM fiscais");
    $total = $stmt->fetch()['total'];
    echo "<br>📊 Total de fiscais cadastrados: $total<br>";
    
    echo "<h2>✅ Atualização Concluída!</h2>";
    echo "<p>A tabela fiscais está pronta para receber cadastros.</p>";
    
    echo "<h3>🔧 Próximos Passos</h3>";
    echo "<a href='debug_cadastro.php' class='btn btn-primary'>Testar Cadastro</a> ";
    echo "<a href='cadastro_fixo.php?concurso=2' class='btn btn-success'>Ir para Cadastro</a> ";
    echo "<a href='admin/' class='btn btn-secondary'>Painel Admin</a>";
    
} catch (Exception $e) {
    echo "❌ Erro na atualização: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
}
?> 