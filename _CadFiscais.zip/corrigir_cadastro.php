<?php
require_once 'config.php';

$mensagem = '';
$erro = '';

try {
    $db = getDB();
    
    if ($db) {
        // Verificar se a configuração cadastro_aberto existe
        $stmt = $db->prepare("SELECT valor FROM configuracoes WHERE chave = 'cadastro_aberto'");
        $stmt->execute();
        $config = $stmt->fetch();
        
        if (!$config) {
            // Inserir configuração de cadastro aberto
            $stmt = $db->prepare("INSERT INTO configuracoes (chave, valor) VALUES ('cadastro_aberto', '1')");
            $stmt->execute();
            $mensagem = 'Configuração de cadastro aberto criada com sucesso!';
        } else {
            // Atualizar para cadastro aberto
            $stmt = $db->prepare("UPDATE configuracoes SET valor = '1' WHERE chave = 'cadastro_aberto'");
            $stmt->execute();
            $mensagem = 'Cadastro aberto com sucesso!';
        }
        
        // Verificar outras configurações necessárias
        $configuracoes_necessarias = [
            'cadastro_aberto' => '1',
            'idade_minima' => '18',
            'ddi_padrao' => '+55',
            'max_fiscais_por_concurso' => '100'
        ];
        
        foreach ($configuracoes_necessarias as $chave => $valor) {
            $stmt = $db->prepare("INSERT INTO configuracoes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = ?");
            $stmt->execute([$chave, $valor, $valor]);
        }
        
    } else {
        $erro = 'Erro ao conectar com MySQL';
    }
    
} catch (Exception $e) {
    $erro = 'Erro ao corrigir configurações: ' . $e->getMessage();
}

// Verificar status atual
$cadastro_aberto = getConfig('cadastro_aberto', '0');
$idade_minima = getConfig('idade_minima', '18');
$ddi_padrao = getConfig('ddi_padrao', '+55');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Corrigir Cadastro - Sistema IDH</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Corrigir Configurações de Cadastro</h1>
            <p>Sistema de Cadastro de Fiscais - IDH</p>
        </div>
        
        <?php if ($mensagem): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($erro): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($erro); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Status das Configurações</h2>
            
            <div class="status-grid">
                <div class="status-item <?php echo $cadastro_aberto == '1' ? 'success' : 'error'; ?>">
                    <strong>Cadastro Aberto:</strong>
                    <span><?php echo $cadastro_aberto == '1' ? '✅ Sim' : '❌ Não'; ?></span>
                </div>
                
                <div class="status-item success">
                    <strong>Idade Mínima:</strong>
                    <span><?php echo $idade_minima; ?> anos</span>
                </div>
                
                <div class="status-item success">
                    <strong>DDI Padrão:</strong>
                    <span><?php echo $ddi_padrao; ?></span>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>🔧 Ações</h2>
            
            <div class="form-group">
                <a href="index.php" class="btn btn-primary">Ir para Página Principal</a>
                <a href="cadastro.php" class="btn btn-secondary">Testar Cadastro</a>
                <a href="admin/configuracoes.php" class="btn btn-info">Configurações</a>
            </div>
        </div>
        
        <div class="card">
            <h2>📋 Informações</h2>
            
            <h3>O que foi corrigido:</h3>
            <ul>
                <li>✅ <strong>cadastro_aberto</strong> = '1' (cadastro aberto)</li>
                <li>✅ <strong>idade_minima</strong> = '18' (idade mínima)</li>
                <li>✅ <strong>ddi_padrao</strong> = '+55' (Brasil)</li>
                <li>✅ <strong>max_fiscais_por_concurso</strong> = '100' (limite)</li>
            </ul>
            
            <h3>Por que aparecia "cadastro_fechado":</h3>
            <ul>
                <li>❌ A configuração <strong>cadastro_aberto</strong> não existia</li>
                <li>❌ Ou estava definida como '0' (fechado)</li>
                <li>✅ Agora está definida como '1' (aberto)</li>
            </ul>
            
            <h3>Como testar:</h3>
            <ol>
                <li>Clique em "Ir para Página Principal"</li>
                <li>Selecione um concurso</li>
                <li>Clique em "Inscrever-se"</li>
                <li>O formulário deve aparecer normalmente</li>
            </ol>
        </div>
    </div>
    
    <style>
    .status-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
        margin: 15px 0;
    }
    .status-item {
        padding: 10px;
        border-radius: 5px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .status-item.success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .status-item.error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    </style>
</body>
</html> 