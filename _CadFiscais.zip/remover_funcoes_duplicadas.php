<?php
echo "<h1>Removendo Funções Duplicadas</h1>";

$arquivos = [
    'admin/relatorio_fiscais_aprovados.php',
    'admin/relatorio_fiscais_horario.php',
    'admin/relatorio_comparecimento.php',
    'admin/relatorio_alocacoes.php',
    'admin/recibo_pagamento.php',
    'admin/planilha_pagamentos.php',
    'admin/lista_pagamentos.php',
    'admin/alocar_fiscal_simples.php'
];

foreach ($arquivos as $arquivo) {
    if (file_exists($arquivo)) {
        echo "<h3>Processando: $arquivo</h3>";
        
        $conteudo = file_get_contents($arquivo);
        
        // Remover função formatPhone
        $conteudo = preg_replace('/function formatPhone\(\$phone\) \{[^}]*\}/s', '', $conteudo);
        
        // Remover função formatCPF
        $conteudo = preg_replace('/function formatCPF\(\$cpf\) \{[^}]*\}/s', '', $conteudo);
        
        // Limpar linhas vazias extras
        $conteudo = preg_replace('/\n\s*\n\s*\n/', "\n\n", $conteudo);
        
        file_put_contents($arquivo, $conteudo);
        
        echo "✅ Funções duplicadas removidas de $arquivo<br>";
    } else {
        echo "⚠️ Arquivo não encontrado: $arquivo<br>";
    }
}

echo "<h2>✅ Processo Concluído!</h2>";
echo "<p>As funções formatPhone() e formatCPF() foram removidas dos arquivos listados.</p>";
echo "<p>Agora essas funções estão disponíveis apenas no arquivo config.php.</p>";

echo "<hr>";
echo "<p><a href='index.php'>← Voltar ao Dashboard</a></p>";
?> 