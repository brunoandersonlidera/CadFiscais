<?php
require_once 'config.php';

echo "<h1>Atualização das Tabelas</h1>";

try {
    $db = getDB();
    if (!$db) {
        throw new Exception("Erro de conexão com banco de dados");
    }
    
    echo "<h2>Adicionando campos na tabela concursos...</h2>";
    
    // Remover criação de colunas antigas já existentes
    // $db->exec("ALTER TABLE concursos ADD COLUMN numero_concurso VARCHAR(50)");
    // $db->exec("ALTER TABLE concursos ADD COLUMN ano_concurso INT");
    
    // Adicionar campos de treinamento e material/manual ao concursos (MySQL/MariaDB)
    if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
        $colunas_novas_mysql = [
            'data_treinamento' => 'DATE NULL',
            'hora_treinamento' => 'TIME NULL',
            'tipo_treinamento' => "VARCHAR(20) DEFAULT 'presencial'",
            'link_treinamento' => 'VARCHAR(255) NULL',
            'local_treinamento' => 'VARCHAR(255) NULL',
            'link_material_fiscal' => 'VARCHAR(255) NULL'
        ];
        $res = $db->query("SHOW COLUMNS FROM concursos");
        $colunas = array_column($res->fetchAll(PDO::FETCH_ASSOC), 'Field');
        foreach ($colunas_novas_mysql as $campo => $tipo) {
            if (!in_array($campo, $colunas)) {
                try {
                    $db->exec("ALTER TABLE concursos ADD COLUMN $campo $tipo");
                    echo "<p>Coluna <b>$campo</b> adicionada à tabela concursos (MySQL).</p>";
                } catch (Exception $e) {
                    echo "<p style='color:red;'>Erro ao adicionar coluna $campo: ".$e->getMessage()."</p>";
                }
            } else {
                echo "<p>Coluna <b>$campo</b> já existe na tabela concursos.</p>";
            }
        }
    }
    
    echo "<h2>Adicionando campos na tabela escolas...</h2>";
    
    // Adicionar campos na tabela escolas
    $db->exec("ALTER TABLE escolas ADD COLUMN coordenador_idh VARCHAR(255)");
    echo "<p>✓ Campo coordenador_idh adicionado</p>";
    
    $db->exec("ALTER TABLE escolas ADD COLUMN coordenador_comissao VARCHAR(255)");
    echo "<p>✓ Campo coordenador_comissao adicionado</p>";
    
    echo "<h2>Atualização concluída com sucesso!</h2>";
    echo "<p>As tabelas foram atualizadas com os novos campos necessários.</p>";
    
} catch (Exception $e) {
    echo "<h2>Erro durante a atualização:</h2>";
    echo "<p style='color: red;'>" . $e->getMessage() . "</p>";
    
    // Se o erro for sobre coluna já existir, ignorar
    if (strpos($e->getMessage(), 'duplicate column name') !== false || 
        strpos($e->getMessage(), 'already exists') !== false) {
        echo "<p>Alguns campos já existem. Isso é normal se você já executou este script antes.</p>";
    }
}

echo "<br><a href='admin/dashboard.php'>Voltar ao Painel Administrativo</a>";
?> 