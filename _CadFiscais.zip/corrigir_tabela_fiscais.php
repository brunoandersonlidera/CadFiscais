<?php
require_once 'config.php';

echo "<h1>Correção da Tabela Fiscais</h1>";

$db = getDB();
if (!$db) {
    echo "<p style='color: red;'>❌ Erro de conexão com banco de dados</p>";
    exit;
}

echo "<h2>1. Verificando Estrutura Atual</h2>";

try {
    $stmt = $db->query("DESCRIBE fiscais");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $colunas_existentes = [];
    foreach ($colunas as $coluna) {
        $colunas_existentes[] = $coluna['Field'];
    }
    
    echo "<p>Colunas existentes na tabela fiscais:</p>";
    echo "<ul>";
    foreach ($colunas_existentes as $coluna) {
        echo "<li>" . htmlspecialchars($coluna) . "</li>";
    }
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Erro ao verificar estrutura: " . $e->getMessage() . "</p>";
    exit;
}

echo "<h2>2. Adicionando Colunas Necessárias</h2>";

$alteracoes = [];

// Verificar se escola_id existe
if (!in_array('escola_id', $colunas_existentes)) {
    try {
        $db->exec("ALTER TABLE fiscais ADD COLUMN escola_id INT NULL");
        echo "<p style='color: green;'>✅ Coluna 'escola_id' adicionada com sucesso</p>";
        $alteracoes[] = "escola_id";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro ao adicionar escola_id: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color: blue;'>ℹ️ Coluna 'escola_id' já existe</p>";
}

// Verificar se sala_id existe
if (!in_array('sala_id', $colunas_existentes)) {
    try {
        $db->exec("ALTER TABLE fiscais ADD COLUMN sala_id INT NULL");
        echo "<p style='color: green;'>✅ Coluna 'sala_id' adicionada com sucesso</p>";
        $alteracoes[] = "sala_id";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro ao adicionar sala_id: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color: blue;'>ℹ️ Coluna 'sala_id' já existe</p>";
}

echo "<h2>3. Adicionando Chaves Estrangeiras</h2>";

// Verificar se a tabela escolas existe
try {
    $stmt = $db->query("SHOW TABLES LIKE 'escolas'");
    if ($stmt->rowCount() > 0) {
        // Adicionar foreign key para escola_id
        try {
            $db->exec("ALTER TABLE fiscais ADD CONSTRAINT fk_fiscais_escola FOREIGN KEY (escola_id) REFERENCES escolas(id) ON DELETE SET NULL");
            echo "<p style='color: green;'>✅ Foreign key para escola_id adicionada</p>";
        } catch (Exception $e) {
            echo "<p style='color: orange;'>⚠️ Foreign key para escola_id já existe ou erro: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: orange;'>⚠️ Tabela 'escolas' não existe</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Erro ao verificar tabela escolas: " . $e->getMessage() . "</p>";
}

// Verificar se a tabela salas existe
try {
    $stmt = $db->query("SHOW TABLES LIKE 'salas'");
    if ($stmt->rowCount() > 0) {
        // Adicionar foreign key para sala_id
        try {
            $db->exec("ALTER TABLE fiscais ADD CONSTRAINT fk_fiscais_sala FOREIGN KEY (sala_id) REFERENCES salas(id) ON DELETE SET NULL");
            echo "<p style='color: green;'>✅ Foreign key para sala_id adicionada</p>";
        } catch (Exception $e) {
            echo "<p style='color: orange;'>⚠️ Foreign key para sala_id já existe ou erro: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: orange;'>⚠️ Tabela 'salas' não existe</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Erro ao verificar tabela salas: " . $e->getMessage() . "</p>";
}

echo "<h2>4. Verificação Final</h2>";

try {
    $stmt = $db->query("DESCRIBE fiscais");
    $colunas_finais = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $escola_id_final = false;
    $sala_id_final = false;
    
    foreach ($colunas_finais as $coluna) {
        if ($coluna['Field'] === 'escola_id') {
            $escola_id_final = true;
        }
        if ($coluna['Field'] === 'sala_id') {
            $sala_id_final = true;
        }
    }
    
    if ($escola_id_final) {
        echo "<p style='color: green;'>✅ Coluna 'escola_id' está presente</p>";
    } else {
        echo "<p style='color: red;'>❌ Coluna 'escola_id' ainda não está presente</p>";
    }
    
    if ($sala_id_final) {
        echo "<p style='color: green;'>✅ Coluna 'sala_id' está presente</p>";
    } else {
        echo "<p style='color: red;'>❌ Coluna 'sala_id' ainda não está presente</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Erro na verificação final: " . $e->getMessage() . "</p>";
}

echo "<h2>5. Teste das Funcionalidades</h2>";

if ($escola_id_final && $sala_id_final) {
    echo "<p style='color: green;'>✅ Tabela corrigida com sucesso!</p>";
    echo "<p><strong>Links para testar:</strong></p>";
    echo "<ul>";
    echo "<li><a href='presenca_prova.php?concurso_id=6' target='_blank'>📝 Presença na Prova</a></li>";
    echo "<li><a href='presenca_treinamento.php?concurso_id=6' target='_blank'>📚 Presença no Treinamento</a></li>";
    echo "<li><a href='teste_presenca_escola.php' target='_blank'>🧪 Teste Completo</a></li>";
    echo "</ul>";
} else {
    echo "<p style='color: red;'>❌ Ainda há problemas com a estrutura da tabela</p>";
    echo "<p>Verifique se você tem permissões para alterar a estrutura da tabela no banco de dados.</p>";
}

echo "<hr>";
echo "<p><strong>Correção concluída!</strong></p>";
echo "<p><a href='index.php'>← Voltar ao Dashboard</a></p>";
?> 