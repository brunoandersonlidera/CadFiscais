<?php
require_once 'config.php';

echo "<h1>🔧 Corrigindo Tipos de Alocação</h1>";

$db = getDB();

try {
    // Verificar alocações sem tipo
    $stmt = $db->query("SELECT COUNT(*) FROM alocacoes_fiscais WHERE tipo_alocacao IS NULL OR tipo_alocacao = ''");
    $total_sem_tipo = $stmt->fetchColumn();
    
    echo "<p>Alocações sem tipo definido: {$total_sem_tipo}</p>";
    
    if ($total_sem_tipo > 0) {
        // Atualizar alocações sem tipo para 'prova' (padrão)
        $stmt = $db->prepare("UPDATE alocacoes_fiscais SET tipo_alocacao = 'prova' WHERE tipo_alocacao IS NULL OR tipo_alocacao = ''");
        $stmt->execute();
        
        echo "<p style='color: green;'>✅ Tipos de alocação corrigidos!</p>";
        
        // Verificar resultado
        $stmt = $db->query("SELECT COUNT(*) FROM alocacoes_fiscais WHERE tipo_alocacao IS NULL OR tipo_alocacao = ''");
        $novo_total = $stmt->fetchColumn();
        
        echo "<p>Alocações sem tipo após correção: {$novo_total}</p>";
    } else {
        echo "<p style='color: blue;'>ℹ️ Todas as alocações já têm tipo definido</p>";
    }
    
    // Mostrar distribuição de tipos
    echo "<h3>Distribuição de Tipos de Alocação:</h3>";
    $stmt = $db->query("
        SELECT tipo_alocacao, COUNT(*) as total 
        FROM alocacoes_fiscais 
        GROUP BY tipo_alocacao 
        ORDER BY total DESC
    ");
    $tipos = $stmt->fetchAll();
    
    foreach ($tipos as $tipo) {
        echo "- {$tipo['tipo_alocacao']}: {$tipo['total']} alocações<br>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
}

echo "<br><a href='admin/lista_presenca_treinamento.php'>Ir para Lista de Presença</a>";
echo "<br><a href='teste_lista_presenca.php'>Testar Consulta Novamente</a>";
?> 