<?php
require_once 'config.php';

echo "<h1>🔧 Remoção de Restrições da Tabela Fiscais</h1>";

$db = getDB();
if (!$db) {
    echo "❌ Erro na conexão com banco<br>";
    exit;
}

try {
    echo "<h2>1. Verificando Restrições de Chave Estrangeira</h2>";
    
    // Verificar restrições que referenciam a tabela fiscais
    $stmt = $db->query("
        SELECT 
            TABLE_NAME,
            COLUMN_NAME,
            CONSTRAINT_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE 
        WHERE REFERENCED_TABLE_NAME = 'fiscais'
    ");
    
    $restricoes = $stmt->fetchAll();
    
    if (empty($restricoes)) {
        echo "✅ Nenhuma restrição encontrada que referencie a tabela fiscais<br>";
    } else {
        echo "⚠️ Restrições encontradas:<br>";
        foreach ($restricoes as $restricao) {
            echo "- Tabela: {$restricao['TABLE_NAME']}, Coluna: {$restricao['COLUMN_NAME']}, ";
            echo "Restrição: {$restricao['CONSTRAINT_NAME']}<br>";
        }
        
        echo "<h3>Removendo restrições...</h3>";
        foreach ($restricoes as $restricao) {
            $sql = "ALTER TABLE {$restricao['TABLE_NAME']} DROP FOREIGN KEY {$restricao['CONSTRAINT_NAME']}";
            $db->exec($sql);
            echo "✅ Removida restrição: {$restricao['CONSTRAINT_NAME']}<br>";
        }
    }
    
    // Verificar restrições na própria tabela fiscais
    echo "<h2>2. Verificando Restrições na Tabela Fiscais</h2>";
    
    $stmt = $db->query("
        SELECT 
            CONSTRAINT_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE 
        WHERE TABLE_NAME = 'fiscais' AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    
    $restricoes_fiscais = $stmt->fetchAll();
    
    if (empty($restricoes_fiscais)) {
        echo "✅ Nenhuma restrição de chave estrangeira na tabela fiscais<br>";
    } else {
        echo "⚠️ Restrições encontradas na tabela fiscais:<br>";
        foreach ($restricoes_fiscais as $restricao) {
            echo "- Coluna: {$restricao['COLUMN_NAME']}, ";
            echo "Referencia: {$restricao['REFERENCED_TABLE_NAME']}.{$restricao['REFERENCED_COLUMN_NAME']}, ";
            echo "Restrição: {$restricao['CONSTRAINT_NAME']}<br>";
        }
        
        echo "<h3>Removendo restrições...</h3>";
        foreach ($restricoes_fiscais as $restricao) {
            $sql = "ALTER TABLE fiscais DROP FOREIGN KEY {$restricao['CONSTRAINT_NAME']}";
            $db->exec($sql);
            echo "✅ Removida restrição: {$restricao['CONSTRAINT_NAME']}<br>";
        }
    }
    
    echo "<h2>3. Verificando Índices</h2>";
    
    $stmt = $db->query("SHOW INDEX FROM fiscais");
    $indices = $stmt->fetchAll();
    
    echo "Índices encontrados:<br>";
    foreach ($indices as $indice) {
        echo "- {$indice['Key_name']} em {$indice['Column_name']}<br>";
    }
    
    echo "<h2>4. Teste de Remoção da Tabela</h2>";
    
    try {
        $db->exec("DROP TABLE IF EXISTS fiscais");
        echo "✅ Tabela fiscais removida com sucesso!<br>";
        
        echo "<h2>5. Recriando Tabela Fiscais</h2>";
        
        $sql = "
        CREATE TABLE fiscais (
            id INT AUTO_INCREMENT PRIMARY KEY,
            concurso_id INT NOT NULL,
            nome VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            ddi VARCHAR(10) NOT NULL DEFAULT '+55',
            celular VARCHAR(20) NOT NULL,
            whatsapp VARCHAR(20) NULL,
            cpf VARCHAR(14) NOT NULL,
            data_nascimento DATE NOT NULL,
            genero ENUM('M', 'F') NOT NULL,
            endereco TEXT NOT NULL,
            melhor_horario VARCHAR(50) NULL,
            observacoes TEXT NULL,
            status ENUM('pendente', 'aprovado', 'reprovado', 'cancelado') DEFAULT 'pendente',
            status_contato ENUM('nao_contatado', 'contatado', 'confirmado', 'desistiu') DEFAULT 'nao_contatado',
            aceite_termos TINYINT(1) DEFAULT 0,
            data_aceite_termos DATETIME NULL,
            ip_cadastro VARCHAR(45) NULL,
            user_agent TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_concurso_id (concurso_id),
            INDEX idx_cpf (cpf),
            INDEX idx_email (email),
            INDEX idx_status (status),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ";
        
        $db->exec($sql);
        echo "✅ Nova tabela fiscais criada com sucesso!<br>";
        
        echo "<h2>6. Teste de Inserção</h2>";
        
        $stmt = $db->prepare("
            INSERT INTO fiscais (
                concurso_id, nome, email, ddi, celular, cpf, 
                data_nascimento, genero, endereco, status, 
                aceite_termos, data_aceite_termos, ip_cadastro, user_agent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $resultado = $stmt->execute([
            2, 'Teste Limpeza', 'teste@limpeza.com', '+55', '(11) 66666-6666',
            '11122233344', '1990-01-01', 'M', 'Rua Teste, 123', 'pendente',
            1, date('Y-m-d H:i:s'), '127.0.0.1', 'Limpeza Script'
        ]);
        
        if ($resultado) {
            $fiscal_id = $db->lastInsertId();
            echo "✅ Inserção de teste bem-sucedida! ID: $fiscal_id<br>";
            
            // Limpar o teste
            $db->exec("DELETE FROM fiscais WHERE id = $fiscal_id");
            echo "✅ Registro de teste removido<br>";
        } else {
            echo "❌ Erro na inserção de teste<br>";
        }
        
        echo "<h2>✅ Limpeza Concluída!</h2>";
        echo "<p>A tabela fiscais foi recriada sem problemas.</p>";
        
        echo "<h3>🔧 Próximos Passos</h3>";
        echo "<a href='teste_cadastro.php' class='btn btn-primary'>Testar Cadastro</a> ";
        echo "<a href='cadastro_fixo.php?concurso=2' class='btn btn-success'>Ir para Cadastro</a> ";
        echo "<a href='admin/' class='btn btn-secondary'>Painel Admin</a>";
        
    } catch (Exception $e) {
        echo "❌ Erro ao recriar tabela: " . $e->getMessage() . "<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro na limpeza: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
}
?> 