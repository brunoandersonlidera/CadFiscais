<?php
require_once 'config.php';

echo "<h1>Correção dos Dados para Dashboard</h1>";

// Verificar se o usuário está logado
if (!isLoggedIn()) {
    echo "<p style='color: red;'>❌ Usuário não está logado</p>";
    echo "<p><a href='login.php'>Fazer Login</a></p>";
    exit;
}

$db = getDB();

echo "<h2>1. Verificar Estrutura da Tabela Fiscais</h2>";
try {
    $stmt = $db->query("DESCRIBE fiscais");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Colunas da tabela fiscais:</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($colunas as $coluna) {
        echo "<tr>";
        echo "<td>{$coluna['Field']}</td>";
        echo "<td>{$coluna['Type']}</td>";
        echo "<td>{$coluna['Null']}</td>";
        echo "<td>{$coluna['Key']}</td>";
        echo "<td>{$coluna['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro ao verificar estrutura: " . $e->getMessage() . "</p>";
}

echo "<h2>2. Verificar Fiscais sem Concurso</h2>";
try {
    $stmt = $db->query("
        SELECT 
            f.id,
            f.nome,
            f.status,
            f.concurso_id,
            c.titulo as concurso_titulo
        FROM fiscais f
        LEFT JOIN concursos c ON f.concurso_id = c.id
        WHERE f.concurso_id IS NULL OR f.concurso_id = 0
        ORDER BY f.id DESC
        LIMIT 10
    ");
    $fiscais_sem_concurso = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Fiscais sem concurso: <strong>" . count($fiscais_sem_concurso) . "</strong></p>";
    
    if (count($fiscais_sem_concurso) > 0) {
        echo "<h3>Fiscais sem concurso:</h3>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Nome</th><th>Status</th><th>Concurso ID</th></tr>";
        foreach ($fiscais_sem_concurso as $fiscal) {
            echo "<tr>";
            echo "<td>{$fiscal['id']}</td>";
            echo "<td>{$fiscal['nome']}</td>";
            echo "<td>{$fiscal['status']}</td>";
            echo "<td>{$fiscal['concurso_id']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Perguntar se quer corrigir
        echo "<h3>Corrigir Fiscais sem Concurso?</h3>";
        echo "<p>Isso irá atribuir o primeiro concurso ativo aos fiscais sem concurso.</p>";
        echo "<button onclick=\"corrigirFiscais()\" class='btn btn-warning'>Corrigir Fiscais</button>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro ao verificar fiscais sem concurso: " . $e->getMessage() . "</p>";
}

echo "<h2>3. Verificar Status dos Fiscais</h2>";
try {
    $stmt = $db->query("
        SELECT 
            status,
            COUNT(*) as quantidade
        FROM fiscais 
        GROUP BY status
    ");
    $status_fiscais = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Distribuição por status:</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Status</th><th>Quantidade</th></tr>";
    foreach ($status_fiscais as $status) {
        echo "<tr>";
        echo "<td>{$status['status']}</td>";
        echo "<td>{$status['quantidade']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro ao verificar status: " . $e->getMessage() . "</p>";
}

echo "<h2>4. Teste do Dashboard</h2>";
echo "<p><a href='admin/dashboard.php' target='_blank' class='btn btn-primary'>📊 Acessar Dashboard</a></p>";

echo "<script>";
echo "function corrigirFiscais() {";
echo "    if (confirm('Tem certeza que deseja corrigir os fiscais sem concurso?')) {";
echo "        fetch('corrigir_fiscais_sem_concurso.php', {";
echo "            method: 'POST'";
echo "        })";
echo "        .then(response => response.json())";
echo "        .then(data => {";
echo "            if (data.success) {";
echo "                alert('Fiscais corrigidos com sucesso!');";
echo "                location.reload();";
echo "            } else {";
echo "                alert('Erro: ' + data.message);";
echo "            }";
echo "        })";
echo "        .catch(error => {";
echo "            alert('Erro ao corrigir fiscais');";
echo "        });";
echo "    }";
echo "}";
echo "</script>";

echo "<hr>";
echo "<p><strong>Verificação concluída!</strong></p>";
echo "<p><a href='index.php'>← Voltar ao Dashboard</a></p>";
?> 