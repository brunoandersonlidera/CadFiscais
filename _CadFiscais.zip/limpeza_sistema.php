<?php
require_once 'config.php';

/**
 * Script de Limpeza do Sistema - CadFiscais
 * Identifica e remove arquivos desnecessários
 */

echo "<h1>🧹 Limpeza do Sistema CadFiscais</h1>";
echo "<p>Este script identifica e remove arquivos desnecessários do sistema.</p>";

// Arquivos ESSENCIAIS (NÃO REMOVER)
$arquivos_essenciais = [
    // Arquivos principais
    'config.php',
    'index.php',
    'cadastro.php',
    'processar_cadastro.php',
    'sucesso.php',
    'login.php',
    'logout.php',
    'style.css',
    'ddi.php',
    'get_termos_concurso.php',
    'verificar_cpf.php',
    'pagamentos.php',
    'relatorios.php',
    'presenca_mobile.php',
    'presenca_prova.php',
    'presenca_treinamento.php',
    '.htaccess',
    '.gitignore',
    'README.md',
    'config.example.php',
    
    // Includes
    'includes/header.php',
    'includes/footer.php',
    
    // Admin essenciais
    'admin/dashboard.php',
    'admin/concursos.php',
    'admin/novo_concurso.php',
    'admin/editar_concurso.php',
    'admin/fiscais.php',
    'admin/editar_fiscal.php',
    'admin/salvar_edicao_fiscal.php',
    'admin/escolas.php',
    'admin/salvar_escola.php',
    'admin/salas.php',
    'admin/salvar_sala.php',
    'admin/alocar_fiscal.php',
    'admin/alocar_fiscais.php',
    'admin/salvar_alocacao.php',
    'admin/lista_presenca.php',
    'admin/lista_presenca_treinamento.php',
    'admin/lista_pagamentos.php',
    'admin/novo_pagamento.php',
    'admin/salvar_pagamento.php',
    'admin/marcar_pagamento_pago.php',
    'admin/planilha_pagamentos.php',
    'admin/recibo_pagamento.php',
    'admin/relatorios.php',
    'admin/relatorio_alocacoes.php',
    'admin/relatorio_comparecimento.php',
    'admin/relatorio_fiscais.php',
    'admin/relatorio_fiscais_aprovados.php',
    'admin/relatorio_fiscais_horario.php',
    'admin/relatorio_concurso.php',
    'admin/relatorio_escola.php',
    'admin/resumo_financeiro.php',
    'admin/ata_treinamento.php',
    'admin/export.php',
    'admin/export_direto.php',
    'admin/exportar_excel_fiscais.php',
    'admin/exportar_excel_fiscais_aprovados.php',
    'admin/exportar_pdf_fiscais.php',
    'admin/exportar_pdf_fiscais_aprovados.php',
    'admin/exportar_pdf_presenca.php',
    'admin/exportar_pdf_ata_treinamento.php',
    'admin/configuracoes.php',
    'admin/toggle_cadastro.php',
    'admin/toggle_status_escola.php',
    'admin/toggle_status_sala.php',
    'admin/buscar_alocacoes_sala.php',
    'admin/buscar_escola.php',
    'admin/buscar_escola_simples.php',
    'admin/buscar_sala.php',
    'admin/buscar_salas_escola.php',
    'admin/get_salas.php',
    'admin/get_fiscal.php',
    'admin/get_estatisticas_alocacao.php',
    'admin/guia_acesso.php',
    'admin/logout.php',
    'admin/criar_tabela_alocacoes.php',
    
    // Sistema de usuários (novo)
    'admin/usuarios.php',
    'admin/novo_usuario.php',
    'admin/editar_usuario.php',
    'admin/salvar_usuario.php',
    'admin/atualizar_usuario.php',
    'admin/get_usuario.php',
    'admin/delete_usuario.php',
    'admin/tipos_usuario.php',
    'admin/novo_tipo_usuario.php',
    'admin/editar_tipo_usuario.php',
    'admin/get_tipo_usuario.php',
    'admin/delete_tipo_usuario.php',
    
    // Gerador de dados (útil para testes)
    'gerador_dados/index.php',
    'gerador_dados/gerar_concurso.php',
    'gerador_dados/gerar_escolas.php',
    'gerador_dados/gerar_salas.php',
    'gerador_dados/gerar_fiscais.php',
    
    // Logs
    'logs/system.log'
];

// Arquivos para REMOÇÃO (TESTE/DEBUG/TEMPORÁRIOS)
$arquivos_para_remover = [
    // Arquivos de teste principais
    'teste_cadastro.php',
    'teste_final_cadastro.php',
    'teste_validacoes_cadastro.php',
    'teste_detalhes_fiscal.php',
    'teste_alocar_fiscais.php',
    'teste_concursos_vagas.php',
    'teste_dashboard_grafico.php',
    'teste_grafico_idade.php',
    'teste_export.php',
    'teste_export_simples.php',
    'teste_export_final.php',
    'teste_export_botoes.php',
    'teste_fiscais.php',
    'teste_fiscais_aprovados.php',
    'teste_funcoes.php',
    'teste_presenca.php',
    'teste_presenca_escola.php',
    'teste_consulta_presenca.php',
    'teste_alocacoes.php',
    'teste_alocacoes_presenca.php',
    'teste_relatorio_fiscais.php',
    'teste_simples.php',
    'teste_acesso_alocar.php',
    'teste_escolas.php',
    
    // Arquivos de debug
    'debug_cadastro.php',
    'verificar_cpf.php',
    'verificar_dashboard_graficos.php',
    'verificar_dados_grafico.php',
    'verificar_estrutura_fiscais.php',
    'verificar_idade_fiscais.php',
    'verificar_dashboard.php',
    'verificar_fiscais_sem_alocacao.php',
    'verificar_alocacoes.php',
    'verificar_concursos.php',
    'verificar_escolas.php',
    'verificar_problema_julianday.php',
    'verificar_termos_concursos.php',
    
    // Arquivos de correção
    'corrigir_cadastro.php',
    'corrigir_tabela_fiscais.php',
    'atualizar_tabela_fiscais.php',
    'remover_restricoes_fiscais.php',
    'remover_funcoes_duplicadas.php',
    'corrigir_fiscais_sem_concurso.php',
    'corrigir_fiscais_dashboard.php',
    
    // Arquivos de teste no admin
    'admin/teste_auth.php',
    'admin/teste_editar_escola.php',
    'admin/teste_showmessage.php',
    'admin/teste_simples_escola.php',
    'admin/teste_formulario.php',
    'admin/teste_alocacao.php',
    'admin/debug_alocacao.php',
    'admin/debug_console.php',
    'admin/debug_editar_escola.php',
    'admin/salvar_alocacao_debug.php',
    'admin/corrigir_tabela_alocacoes.php',
    'admin/corrigir_tabela_pagamentos.php',
    
    // Arquivos temporários/obsoletos
    'cadastro_fixo.php',
    'cadastro_simples.php',
    'adicionar_fiscais_ajax.php',
    'adicionar_fiscais_teste.php',
    'calcular_idade_ajax.php',
    'calcular_idade_automatico.php',
    'calcular_idade_automatico_ajax.php',
    'calcular_idade_fiscais.php',
    'criar_alocacoes_teste.php',
    'criar_dados_teste.php',
    'atualizar_tabelas.php',
    
    // Arquivos de documentação temporários
    'ANALISE_SISTEMA.md',
    'CORREÇÃO_CADASTRO_FINAL.md',
    'CORREÇÃO_DETALHES_FISCAL.md',
    'CORREÇÃO_FUNÇÃO_DUPLICADA.md',
    'CORREÇÃO_VAGAS_CONCURSOS.md',
    'NOVA_PÁGINA_ALOCAR_FISCAIS.md',
    'RESUMO_MODIFICACOES.md',
    'MELHORIAS_CADASTRO_FISCAIS.md',
    'GERADOR_DADOS_FICTICIOS.md',
    'GUIA_ADMINISTRATIVO.md',
    
    // Arquivos duplicados/obsoletos
    'admin/alocar_fiscal_simples.php',
    'admin/alocacao_automatica.php',
    
    // Logs antigos (manter apenas system.log)
    'logs/2025-01-*.log',
    'logs/debug_*.log'
];

// Processar remoção se solicitado
if (isset($_GET['action']) && $_GET['action'] === 'remove') {
    echo "<h2>🗑️ Removendo Arquivos...</h2>";
    
    $removidos = 0;
    $erros = 0;
    
    foreach ($arquivos_para_remover as $arquivo) {
        if (file_exists($arquivo)) {
            if (unlink($arquivo)) {
                echo "✅ Removido: $arquivo<br>";
                $removidos++;
            } else {
                echo "❌ Erro ao remover: $arquivo<br>";
                $erros++;
            }
        } else {
            echo "⚠️ Não encontrado: $arquivo<br>";
        }
    }
    
    echo "<hr>";
    echo "<h3>📊 Resumo da Limpeza</h3>";
    echo "<p>✅ Arquivos removidos: $removidos</p>";
    echo "<p>❌ Erros: $erros</p>";
    echo "<p>⚠️ Não encontrados: " . (count($arquivos_para_remover) - $removidos - $erros) . "</p>";
    
    echo "<hr>";
    echo "<a href='limpeza_sistema.php' class='btn btn-primary'>Voltar</a>";
    exit;
}

// Verificar arquivos essenciais
echo "<h2>✅ Verificação de Arquivos Essenciais</h2>";
$essenciais_ok = 0;
$essenciais_faltando = 0;

foreach ($arquivos_essenciais as $arquivo) {
    if (file_exists($arquivo)) {
        echo "✅ $arquivo<br>";
        $essenciais_ok++;
    } else {
        echo "❌ $arquivo (FALTANDO)<br>";
        $essenciais_faltando++;
    }
}

echo "<hr>";
echo "<h3>📊 Arquivos Essenciais</h3>";
echo "<p>✅ Presentes: $essenciais_ok</p>";
echo "<p>❌ Faltando: $essenciais_faltando</p>";

// Listar arquivos para remoção
echo "<h2>🗑️ Arquivos Identificados para Remoção</h2>";
echo "<p>Estes arquivos são de teste, debug ou temporários e podem ser removidos:</p>";

$arquivos_encontrados = 0;
$tamanho_total = 0;

foreach ($arquivos_para_remover as $arquivo) {
    if (file_exists($arquivo)) {
        $tamanho = filesize($arquivo);
        $tamanho_total += $tamanho;
        $tamanho_kb = round($tamanho / 1024, 2);
        echo "📄 $arquivo ($tamanho_kb KB)<br>";
        $arquivos_encontrados++;
    }
}

echo "<hr>";
echo "<h3>📊 Estatísticas</h3>";
echo "<p>📄 Arquivos encontrados: $arquivos_encontrados</p>";
echo "<p>💾 Espaço que será liberado: " . round($tamanho_total / 1024, 2) . " KB</p>";

// Verificar banco de dados
echo "<h2>🗄️ Análise do Banco de Dados</h2>";
try {
    $db = getDB();
    if ($db) {
        // Verificar tabelas
        $tabelas = [
            'usuarios', 'tipos_usuario', 'concursos', 'escolas', 'salas', 
            'fiscais', 'pagamentos', 'presenca', 'alocacoes', 'configuracoes'
        ];
        
        echo "<h3>📋 Tabelas do Sistema</h3>";
        foreach ($tabelas as $tabela) {
            try {
                $stmt = $db->query("SELECT COUNT(*) as total FROM $tabela");
                $result = $stmt->fetch();
                echo "✅ $tabela: " . $result['total'] . " registros<br>";
            } catch (Exception $e) {
                echo "❌ $tabela: Erro - " . $e->getMessage() . "<br>";
            }
        }
        
        // Verificar registros duplicados
        echo "<h3>🔍 Verificação de Duplicatas</h3>";
        
        // CPFs duplicados
        try {
            $stmt = $db->query("
                SELECT cpf, COUNT(*) as total 
                FROM fiscais 
                GROUP BY cpf 
                HAVING COUNT(*) > 1
            ");
            $duplicatas = $stmt->fetchAll();
            if (count($duplicatas) > 0) {
                echo "⚠️ CPFs duplicados encontrados: " . count($duplicatas) . "<br>";
                foreach ($duplicatas as $dup) {
                    echo "   - CPF: {$dup['cpf']} ({$dup['total']} vezes)<br>";
                }
            } else {
                echo "✅ Nenhum CPF duplicado encontrado<br>";
            }
        } catch (Exception $e) {
            echo "❌ Erro ao verificar CPFs duplicados: " . $e->getMessage() . "<br>";
        }
        
        // Emails duplicados
        try {
            $stmt = $db->query("
                SELECT email, COUNT(*) as total 
                FROM fiscais 
                GROUP BY email 
                HAVING COUNT(*) > 1
            ");
            $duplicatas = $stmt->fetchAll();
            if (count($duplicatas) > 0) {
                echo "⚠️ Emails duplicados encontrados: " . count($duplicatas) . "<br>";
                foreach ($duplicatas as $dup) {
                    echo "   - Email: {$dup['email']} ({$dup['total']} vezes)<br>";
                }
            } else {
                echo "✅ Nenhum email duplicado encontrado<br>";
            }
        } catch (Exception $e) {
            echo "❌ Erro ao verificar emails duplicados: " . $e->getMessage() . "<br>";
        }
        
    } else {
        echo "❌ Não foi possível conectar ao banco de dados<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro na análise do banco: " . $e->getMessage() . "<br>";
}

// Ações
echo "<hr>";
echo "<h2>🔧 Ações Disponíveis</h2>";

if ($arquivos_encontrados > 0) {
    echo "<div class='alert alert-warning'>";
    echo "<h4>⚠️ Atenção!</h4>";
    echo "<p>Foram encontrados <strong>$arquivos_encontrados</strong> arquivos que podem ser removidos.</p>";
    echo "<p>Isso liberará aproximadamente <strong>" . round($tamanho_total / 1024, 2) . " KB</strong> de espaço.</p>";
    echo "</div>";
    
    echo "<a href='limpeza_sistema.php?action=remove' class='btn btn-danger' onclick='return confirm(\"Tem certeza que deseja remover estes arquivos?\")'>";
    echo "🗑️ Remover Arquivos Identificados";
    echo "</a>";
} else {
    echo "<div class='alert alert-success'>";
    echo "<h4>✅ Sistema Limpo!</h4>";
    echo "<p>Nenhum arquivo desnecessário foi encontrado.</p>";
    echo "</div>";
}

echo "<hr>";
echo "<a href='admin/dashboard.php' class='btn btn-primary'>🏠 Voltar ao Dashboard</a> ";
echo "<a href='index.php' class='btn btn-secondary'>📄 Página Inicial</a>";

echo "<hr>";
echo "<h3>📋 Resumo da Limpeza</h3>";
echo "<ul>";
echo "<li>✅ Arquivos essenciais verificados</li>";
echo "<li>🗑️ Arquivos desnecessários identificados</li>";
echo "<li>🗄️ Banco de dados analisado</li>";
echo "<li>🔍 Duplicatas verificadas</li>";
echo "</ul>";

echo "<h3>💡 Recomendações</h3>";
echo "<ul>";
echo "<li>Faça backup antes de remover arquivos</li>";
echo "<li>Teste o sistema após a limpeza</li>";
echo "<li>Mantenha apenas os arquivos essenciais</li>";
echo "<li>Monitore os logs regularmente</li>";
echo "</ul>";
?> 