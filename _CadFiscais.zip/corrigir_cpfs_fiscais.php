<?php
require_once 'config.php';

function gerarCPFValido() {
    do {
        $nove = [];
        for ($i = 0; $i < 9; $i++) {
            $nove[] = rand(0, 9);
        }
        // Calcula o primeiro dígito verificador
        $soma = 0;
        for ($i = 0, $peso = 10; $i < 9; $i++, $peso--) {
            $soma += $nove[$i] * $peso;
        }
        $resto = $soma % 11;
        $d1 = ($resto < 2) ? 0 : 11 - $resto;
        // Calcula o segundo dígito verificador
        $soma = 0;
        for ($i = 0, $peso = 11; $i < 9; $i++, $peso--) {
            $soma += $nove[$i] * $peso;
        }
        $soma += $d1 * 2;
        $resto = $soma % 11;
        $d2 = ($resto < 2) ? 0 : 11 - $resto;
        $cpf = implode('', $nove) . $d1 . $d2;
    } while (!validarCPF($cpf));
    return $cpf;
}

function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11 || preg_match('/^(\d)\1+$/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    return true;
}

try {
    $db = getDB();
    if (!$db) {
        die('Erro de conexão com o banco de dados.');
    }
    $stmt = $db->query('SELECT id FROM fiscais');
    $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $cpfsGerados = [];
    foreach ($ids as $id) {
        do {
            $novoCPF = gerarCPFValido();
        } while (in_array($novoCPF, $cpfsGerados));
        $cpfsGerados[] = $novoCPF;
        $db->prepare('UPDATE fiscais SET cpf = ? WHERE id = ?')->execute([$novoCPF, $id]);
        echo "Fiscal ID $id atualizado para CPF $novoCPF<br>";
    }
    echo '<strong>Todos os CPFs foram atualizados com sucesso!</strong>';
} catch (Exception $e) {
    echo 'Erro: ' . $e->getMessage();
} 