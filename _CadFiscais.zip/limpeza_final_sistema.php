<?php
/**
 * Script de Limpeza Final do Sistema
 * Remove arquivos de teste, debug e temporários
 */

echo "<h1>🧹 Limpeza Final do Sistema</h1>";
echo "<p>Este script remove arquivos desnecessários para deixar o sistema limpo.</p>";

// Lista de arquivos para remover
$arquivos_para_remover = [
    // Arquivos de teste principais
    'teste_cadastro.php',
    'teste_final_cadastro.php',
    'debug_cadastro.php',
    'corrigir_cadastro.php',
    'corrigir_tabela_fiscais.php',
    'atualizar_tabela_fiscais.php',
    'remover_restricoes_fiscais.php',
    'verificar_concursos.php',
    'verificar_escolas.php',
    'verificar_problema_julianday.php',
    'verificar_termos_concursos.php',
    'verificar_dashboard_graficos.php',
    'verificar_dados_grafico.php',
    'verificar_estrutura_fiscais.php',
    'verificar_idade_fiscais.php',
    'verificar_alocacoes.php',
    'verificar_fiscais_sem_alocacao.php',
    'verificar_cpf.php',
    'verificar_dashboard.php',
    
    // Arquivos de teste no admin
    'admin/teste_auth.php',
    'admin/teste_editar_escola.php',
    'admin/teste_showmessage.php',
    'admin/teste_simples_escola.php',
    'admin/debug_console.php',
    'admin/debug_editar_escola.php',
    'admin/teste_formulario.php',
    'admin/salvar_alocacao_debug.php',
    'admin/corrigir_tabela_alocacoes.php',
    'admin/debug_alocacao.php',
    
    // Arquivos de teste diversos
    'teste_validacoes_cadastro.php',
    'teste_detalhes_fiscal.php',
    'teste_alocar_fiscais.php',
    'teste_escolas.php',
    'teste_concursos_vagas.php',
    'teste_presenca.php',
    'teste_presenca_escola.php',
    'teste_consulta_presenca.php',
    'teste_alocacoes_presenca.php',
    'teste_alocacoes.php',
    'teste_fiscais_aprovados.php',
    'teste_relatorio_fiscais.php',
    'teste_export_botoes.php',
    'teste_export_simples.php',
    'teste_export_final.php',
    'teste_export.php',
    'teste_dashboard_grafico.php',
    'teste_grafico_idade.php',
    'teste_fiscais.php',
    'teste_funcoes.php',
    'teste_simples.php',
    'teste_acesso_alocar.php',
    'teste_cadastro.php',
    
    // Arquivos temporários/obsoletos
    'cadastro_fixo.php',
    'cadastro_simples.php',
    'ddi.php',
    'get_termos_concurso.php',
    'instalar_sistema.php',
    'limpeza_arquivos.php',
    'remover_funcoes_duplicadas.php',
    'corrigir_fiscais_sem_concurso.php',
    'corrigir_fiscais_dashboard.php',
    'criar_alocacoes_teste.php',
    'criar_dados_teste.php',
    'adicionar_fiscais_ajax.php',
    'adicionar_fiscais_teste.php',
    'calcular_idade_ajax.php',
    'calcular_idade_automatico_ajax.php',
    'calcular_idade_automatico.php',
    'calcular_idade_fiscais.php',
    'atualizar_tabelas.php',
    
    // Arquivos de documentação temporários
    'ANALISE_SISTEMA.md',
    'CORREÇÃO_CADASTRO_FINAL.md',
    'CORREÇÃO_DETALHES_FISCAL.md',
    'NOVA_PÁGINA_ALOCAR_FISCAIS.md',
    'CORREÇÃO_FUNÇÃO_DUPLICADA.md',
    'CORREÇÃO_VAGAS_CONCURSOS.md',
    'RESUMO_MODIFICACOES.md',
    'GERADOR_DADOS_FICTICIOS.md',
    
    // Logs antigos (manter apenas system.log)
    'logs/2025-07-09.log'
];

// Arquivos da biblioteca TCPDF que podem ser removidos
$arquivos_tcpdf_para_remover = [
    'TCPDF/CHANGELOG.TXT',
    'TCPDF/README.md',
    'TCPDF/VERSION',
    'TCPDF/composer.json',
    'TCPDF/fonts/ae_fonts_2.0/',
    'TCPDF/fonts/freefont-20100919/',
    'TCPDF/fonts/freefont-20120503/',
    'TCPDF/fonts/dejavu-fonts-ttf-2.33/',
    'TCPDF/fonts/dejavu-fonts-ttf-2.34/',
    'TCPDF/tools/'
];

echo "<h2>📋 Arquivos para Remoção</h2>";
echo "<p>Total de arquivos: " . count($arquivos_para_remover) . "</p>";

$removidos = 0;
$erros = 0;

foreach ($arquivos_para_remover as $arquivo) {
    if (file_exists($arquivo)) {
        if (is_dir($arquivo)) {
            // Remover diretório recursivamente
            if (removeDirectory($arquivo)) {
                echo "✅ Removido diretório: $arquivo<br>";
                $removidos++;
            } else {
                echo "❌ Erro ao remover diretório: $arquivo<br>";
                $erros++;
            }
        } else {
            // Remover arquivo
            if (unlink($arquivo)) {
                echo "✅ Removido arquivo: $arquivo<br>";
                $removidos++;
            } else {
                echo "❌ Erro ao remover arquivo: $arquivo<br>";
                $erros++;
            }
        }
    } else {
        echo "ℹ️ Arquivo não encontrado: $arquivo<br>";
    }
}

echo "<h2>📚 Limpeza TCPDF</h2>";
echo "<p>Removendo arquivos desnecessários da biblioteca TCPDF...</p>";

foreach ($arquivos_tcpdf_para_remover as $arquivo) {
    if (file_exists($arquivo)) {
        if (is_dir($arquivo)) {
            if (removeDirectory($arquivo)) {
                echo "✅ Removido diretório TCPDF: $arquivo<br>";
                $removidos++;
            } else {
                echo "❌ Erro ao remover diretório TCPDF: $arquivo<br>";
                $erros++;
            }
        } else {
            if (unlink($arquivo)) {
                echo "✅ Removido arquivo TCPDF: $arquivo<br>";
                $removidos++;
            } else {
                echo "❌ Erro ao remover arquivo TCPDF: $arquivo<br>";
                $erros++;
            }
        }
    }
}

echo "<h2>📊 Resumo da Limpeza</h2>";
echo "<div class='alert alert-success'>";
echo "<strong>✅ Arquivos removidos com sucesso:</strong> $removidos<br>";
if ($erros > 0) {
    echo "<strong>❌ Erros encontrados:</strong> $erros<br>";
}
echo "</div>";

echo "<h2>🎯 Sistema Limpo!</h2>";
echo "<p>O sistema foi limpo com sucesso. Agora contém apenas os arquivos essenciais:</p>";

echo "<h3>📁 Estrutura Final</h3>";
echo "<ul>";
echo "<li><strong>admin/</strong> - Painel administrativo</li>";
echo "<li><strong>includes/</strong> - Arquivos de inclusão</li>";
echo "<li><strong>logos/</strong> - Logos institucionais</li>";
echo "<li><strong>logs/</strong> - Logs do sistema</li>";
echo "<li><strong>TCPDF/</strong> - Biblioteca para PDFs (versão limpa)</li>";
echo "<li><strong>config.php</strong> - Configurações principais</li>";
echo "<li><strong>index.php</strong> - Página inicial</li>";
echo "<li><strong>cadastro.php</strong> - Formulário de cadastro</li>";
echo "<li><strong>processar_cadastro.php</strong> - Processamento</li>";
echo "<li><strong>login.php</strong> - Sistema de login</li>";
echo "<li><strong>relatorios.php</strong> - Relatórios públicos</li>";
echo "<li><strong>pagamentos.php</strong> - Controle de pagamentos</li>";
echo "<li><strong>presenca_prova.php</strong> - Controle de presença</li>";
echo "<li><strong>presenca_treinamento.php</strong> - Presença treinamento</li>";
echo "<li><strong>presenca_mobile.php</strong> - Interface mobile</li>";
echo "</ul>";

echo "<h3>🔧 Próximos Passos</h3>";
echo "<div class='alert alert-info'>";
echo "<p><strong>O sistema está pronto para produção!</strong></p>";
echo "<ul>";
echo "<li>✅ Todos os erros de coluna 'idade' foram corrigidos</li>";
echo "<li>✅ Todos os erros de coluna 'data_atualizacao' foram corrigidos</li>";
echo "<li>✅ Arquivos de teste e debug removidos</li>";
echo "<li>✅ Sistema de usuários e permissões funcionando</li>";
echo "<li>✅ Todas as funcionalidades principais operacionais</li>";
echo "</ul>";
echo "</div>";

echo "<div class='mt-4'>";
echo "<a href='admin/' class='btn btn-primary'>Acessar Painel Admin</a> ";
echo "<a href='index.php' class='btn btn-secondary'>Página Inicial</a> ";
echo "<a href='cadastro.php' class='btn btn-success'>Testar Cadastro</a>";
echo "</div>";

// Função para remover diretório recursivamente
function removeDirectory($dir) {
    if (!is_dir($dir)) {
        return false;
    }
    
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        $path = $dir . DIRECTORY_SEPARATOR . $file;
        if (is_dir($path)) {
            removeDirectory($path);
        } else {
            unlink($path);
        }
    }
    
    return rmdir($dir);
}
?> 