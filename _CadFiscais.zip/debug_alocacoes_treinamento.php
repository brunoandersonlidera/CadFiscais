<?php
require_once 'config.php';

echo "<h1>🔍 Debug - Alocações para Treinamento</h1>";

$db = getDB();

// Verificar fiscais aprovados
echo "<h2>1. Fiscais Aprovados</h2>";
try {
    $stmt = $db->query("SELECT COUNT(*) as total FROM fiscais WHERE status = 'aprovado'");
    $total_fiscais = $stmt->fetchColumn();
    echo "Total de fiscais aprovados: {$total_fiscais}<br>";
    
    $stmt = $db->query("SELECT id, nome, concurso_id FROM fiscais WHERE status = 'aprovado' LIMIT 5");
    $fiscais = $stmt->fetchAll();
    echo "Primeiros 5 fiscais aprovados:<br>";
    foreach ($fiscais as $fiscal) {
        echo "- ID: {$fiscal['id']}, Nome: {$fiscal['nome']}, Concurso: {$fiscal['concurso_id']}<br>";
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage() . "<br>";
}

// Verificar alocações
echo "<h2>2. Alocações de Fiscais</h2>";
try {
    $stmt = $db->query("
        SELECT 
            a.id as alocacao_id,
            a.fiscal_id,
            a.escola_id,
            a.sala_id,
            a.tipo_alocacao,
            a.status as alocacao_status,
            f.nome as fiscal_nome,
            e.nome as escola_nome,
            s.nome as sala_nome
        FROM alocacoes_fiscais a
        LEFT JOIN fiscais f ON a.fiscal_id = f.id
        LEFT JOIN escolas e ON a.escola_id = e.id
        LEFT JOIN salas s ON a.sala_id = s.id
        WHERE a.status = 'ativo'
        ORDER BY a.id DESC
        LIMIT 10
    ");
    $alocacoes = $stmt->fetchAll();
    
    echo "Últimas 10 alocações:<br>";
    foreach ($alocacoes as $alocacao) {
        echo "- Fiscal: {$alocacao['fiscal_nome']}, Escola: {$alocacao['escola_nome']}, Sala: {$alocacao['sala_nome']}, Tipo: {$alocacao['tipo_alocacao']}<br>";
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage() . "<br>";
}

// Verificar consulta completa
echo "<h2>3. Consulta Completa (como no arquivo original)</h2>";
try {
    $sql = "
        SELECT f.*, c.titulo as concurso_titulo, c.data_prova,
               TIMESTAMPDIFF(YEAR, f.data_nascimento, CURDATE()) as idade,
               a.escola_id, a.sala_id, a.data_alocacao, a.horario_alocacao,
               e.nome as escola_nome, s.nome as sala_nome
        FROM fiscais f
        LEFT JOIN concursos c ON f.concurso_id = c.id
        LEFT JOIN alocacoes_fiscais a ON f.id = a.fiscal_id AND a.status = 'ativo'
        LEFT JOIN escolas e ON a.escola_id = e.id
        LEFT JOIN salas s ON a.sala_id = s.id
        WHERE f.status = 'aprovado'
        ORDER BY e.nome, s.nome, f.nome
        LIMIT 10
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $resultados = $stmt->fetchAll();
    
    echo "Resultados da consulta completa:<br>";
    foreach ($resultados as $resultado) {
        echo "- Fiscal: {$resultado['nome']}, Escola: {$resultado['escola_nome']}, Sala: {$resultado['sala_nome']}<br>";
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage() . "<br>";
}

// Verificar estrutura da tabela alocacoes_fiscais
echo "<h2>4. Estrutura da Tabela alocacoes_fiscais</h2>";
try {
    $stmt = $db->query("DESCRIBE alocacoes_fiscais");
    $colunas = $stmt->fetchAll();
    
    echo "Colunas da tabela alocacoes_fiscais:<br>";
    foreach ($colunas as $coluna) {
        echo "- {$coluna['Field']}: {$coluna['Type']}<br>";
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage() . "<br>";
}

echo "<br><a href='admin/lista_presenca_treinamento.php'>Voltar para Lista de Presença</a>";
?> 