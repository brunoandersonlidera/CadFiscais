<?php
require_once 'config.php';

echo "<h1>🔍 Debug de Permissões</h1>";

// Verificar se está logado
echo "<h2>Status de Login</h2>";
echo "isLoggedIn(): " . (isLoggedIn() ? "SIM" : "NÃO") . "<br>";
echo "user_id: " . ($_SESSION['user_id'] ?? 'NÃO DEFINIDO') . "<br>";

// Verificar permissões
echo "<h2>Permissões do Usuário</h2>";
echo "user_permissions: <pre>" . print_r($_SESSION['user_permissions'] ?? [], true) . "</pre>";

echo "<h2>Testes de Permissões</h2>";
echo "isAdmin(): " . (isAdmin() ? "SIM" : "NÃO") . "<br>";
echo "temPermissaoAlocacoes(): " . (temPermissaoAlocacoes() ? "SIM" : "NÃO") . "<br>";
echo "temPermissaoUsuarios(): " . (temPermissaoUsuarios() ? "SIM" : "NÃO") . "<br>";
echo "temPermissaoTiposUsuario(): " . (temPermissaoTiposUsuario() ? "SIM" : "NÃO") . "<br>";
echo "temPermissaoPresenca(): " . (temPermissaoPresenca() ? "SIM" : "NÃO") . "<br>";
echo "temPermissaoPagamentos(): " . (temPermissaoPagamentos() ? "SIM" : "NÃO") . "<br>";

// Verificar dados da sessão
echo "<h2>Dados da Sessão</h2>";
echo "<pre>" . print_r($_SESSION, true) . "</pre>";

// Verificar se pode acessar alocar_fiscais.php
echo "<h2>Teste de Acesso</h2>";
if (!isLoggedIn()) {
    echo "❌ NÃO ESTÁ LOGADO - Seria redirecionado para login.php<br>";
} elseif (!temPermissaoAlocacoes()) {
    echo "❌ NÃO TEM PERMISSÃO DE ALOCAÇÕES - Seria redirecionado para login.php<br>";
} else {
    echo "✅ PODE ACESSAR alocar_fiscais.php<br>";
}

echo "<br><a href='admin/alocar_fiscais.php'>Tentar acessar alocar_fiscais.php</a>";
?> 