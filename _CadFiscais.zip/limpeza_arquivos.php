<?php
/**
 * Script de Limpeza - Identificação de Arquivos Não Utilizados
 * Sistema de Cadastro de Fiscais - IDH
 */

echo "<h1>🧹 Análise de Arquivos Não Utilizados</h1>";
echo "<p>Este script identifica arquivos que podem ser removidos do sistema.</p>";

// Arquivos principais do sistema (NÃO REMOVER)
$arquivos_essenciais = [
    'config.php',
    'index.php',
    'cadastro.php',
    'processar_cadastro.php',
    'sucesso.php',
    'login.php',
    'logout.php',
    'style.css',
    'ddi.php',
    'instalar_sistema.php',
    'pagamentos.php',
    'relatorios.php',
    'presenca_mobile.php',
    '.htaccess',
    'includes/header.php',
    'includes/footer.php',
    'admin/dashboard.php',
    'admin/concursos.php',
    'admin/fiscais.php',
    'admin/escolas.php',
    'admin/salas.php',
    'admin/alocar_fiscal.php',
    'admin/lista_presenca.php',
    'admin/lista_pagamentos.php',
    'admin/relatorios.php',
    'admin/relatorio_alocacoes.php',
    'admin/relatorio_comparecimento.php',
    'admin/relatorio_fiscais.php',
    'admin/relatorio_fiscais_aprovados.php',
    'admin/relatorio_fiscais_horario.php',
    'admin/usuarios.php',
    'admin/configuracoes.php',
    'admin/novo_concurso.php',
    'admin/editar_concurso.php',
    'admin/editar_fiscal.php',
    'admin/export.php',
    'admin/planilha_pagamentos.php',
    'admin/recibo_pagamento.php',
    'admin/ata_treinamento.php',
    'admin/salvar_alocacao.php',
    'admin/salvar_edicao_fiscal.php',
    'admin/salvar_escola.php',
    'admin/salvar_sala.php',
    'admin/buscar_alocacoes_sala.php',
    'admin/buscar_escola.php',
    'admin/buscar_escola_simples.php',
    'admin/buscar_sala.php',
    'admin/buscar_salas_escola.php',
    'admin/get_salas.php',
    'admin/guia_acesso.php',
    'admin/marcar_pagamento_pago.php',
    'admin/toggle_cadastro.php',
    'admin/toggle_status_escola.php',
    'admin/toggle_status_sala.php',
    'admin/criar_tabela_alocacoes.php',
    'admin/logout.php'
];

// Arquivos que podem ser removidos (TESTE/DEBUG/TEMPORÁRIOS)
$arquivos_para_remover = [
    // Arquivos de teste principais
    'teste_cadastro.php',
    'teste_final_cadastro.php',
    'debug_cadastro.php',
    'corrigir_cadastro.php',
    'corrigir_tabela_fiscais.php',
    'atualizar_tabela_fiscais.php',
    'remover_restricoes_fiscais.php',
    'verificar_concursos.php',
    'verificar_escolas.php',
    'verificar_problema_julianday.php',
    
    // Arquivos de teste no admin
    'admin/teste_auth.php',
    'admin/teste_editar_escola.php',
    'admin/teste_showmessage.php',
    'admin/teste_simples_escola.php',
    'admin/debug_console.php',
    'admin/debug_editar_escola.php',
    
    // Arquivos temporários/obsoletos
    'cadastro_fixo.php',
    'cadastro_simples.php',
    
    // Logs antigos (manter apenas system.log)
    'logs/2025-07-09.log'
];

// Arquivos da biblioteca TCPDF que podem ser removidos (manter apenas o essencial)
$arquivos_tcpdf_para_remover = [
    'TCPDF/CHANGELOG.TXT',
    'TCPDF/README.md',
    'TCPDF/VERSION',
    'TCPDF/composer.json',
    'TCPDF/fonts/ae_fonts_2.0/',
    'TCPDF/fonts/freefont-20100919/',
    'TCPDF/fonts/freefont-20120503/',
    'TCPDF/fonts/dejavu-fonts-ttf-2.33/',
    'TCPDF/fonts/dejavu-fonts-ttf-2.34/',
    'TCPDF/tools/'
];

echo "<h2>📋 Arquivos Essenciais (NÃO REMOVER)</h2>";
echo "<p>Estes arquivos são necessários para o funcionamento do sistema:</p>";
echo "<ul>";
foreach ($arquivos_essenciais as $arquivo) {
    $status = file_exists($arquivo) ? "✅" : "❌";
    echo "<li>$status $arquivo</li>";
}
echo "</ul>";

echo "<h2>🗑️ Arquivos para Remoção (TESTE/DEBUG)</h2>";
echo "<p>Estes arquivos podem ser removidos com segurança:</p>";
echo "<ul>";
foreach ($arquivos_para_remover as $arquivo) {
    $status = file_exists($arquivo) ? "✅" : "❌";
    $size = file_exists($arquivo) ? " (" . number_format(filesize($arquivo)) . " bytes)" : "";
    echo "<li>$status $arquivo$size</li>";
}
echo "</ul>";

echo "<h2>📚 Arquivos TCPDF para Remoção</h2>";
echo "<p>Arquivos da biblioteca TCPDF que podem ser removidos para economizar espaço:</p>";
echo "<ul>";
foreach ($arquivos_tcpdf_para_remover as $arquivo) {
    $status = file_exists($arquivo) ? "✅" : "❌";
    if (is_dir($arquivo)) {
        $size = " (diretório)";
    } else {
        $size = file_exists($arquivo) ? " (" . number_format(filesize($arquivo)) . " bytes)" : "";
    }
    echo "<li>$status $arquivo$size</li>";
}
echo "</ul>";

// Calcular espaço que pode ser liberado
$espaco_total = 0;
foreach ($arquivos_para_remover as $arquivo) {
    if (file_exists($arquivo)) {
        $espaco_total += filesize($arquivo);
    }
}

echo "<h2>💾 Espaço que pode ser liberado</h2>";
echo "<p>Total de bytes que podem ser liberados: <strong>" . number_format($espaco_total) . " bytes</strong></p>";
echo "<p>Total em MB: <strong>" . number_format($espaco_total / 1024 / 1024, 2) . " MB</strong></p>";

echo "<h2>🔧 Script de Limpeza Automática</h2>";
echo "<p>Para remover automaticamente os arquivos não utilizados, execute:</p>";
echo "<pre>";
echo "<?php\n";
echo "// Script de limpeza automática\n";
echo "\$arquivos_para_remover = [\n";
foreach ($arquivos_para_remover as $arquivo) {
    echo "    '$arquivo',\n";
}
echo "];\n";
echo "\n";
echo "foreach (\$arquivos_para_remover as \$arquivo) {\n";
echo "    if (file_exists(\$arquivo)) {\n";
echo "        if (is_dir(\$arquivo)) {\n";
echo "            // Remover diretório recursivamente\n";
echo "            function removeDir(\$dir) {\n";
echo "                if (is_dir(\$dir)) {\n";
echo "                    \$files = scandir(\$dir);\n";
echo "                    foreach (\$files as \$file) {\n";
echo "                        if (\$file != '.' && \$file != '..') {\n";
echo "                            removeDir(\$dir . '/' . \$file);\n";
echo "                        }\n";
echo "                    }\n";
echo "                    rmdir(\$dir);\n";
echo "                } else {\n";
echo "                    unlink(\$dir);\n";
echo "                }\n";
echo "            }\n";
echo "            removeDir(\$arquivo);\n";
echo "        } else {\n";
echo "            unlink(\$arquivo);\n";
echo "        }\n";
echo "        echo \"Removido: \$arquivo\\n\";\n";
echo "    }\n";
echo "}\n";
echo "echo \"Limpeza concluída!\\n\";\n";
echo "?>";
echo "</pre>";

echo "<h2>⚠️ Recomendações</h2>";
echo "<ol>";
echo "<li><strong>Faça backup completo</strong> antes de remover qualquer arquivo</li>";
echo "<li><strong>Teste o sistema</strong> após a remoção para garantir funcionamento</li>";
echo "<li><strong>Mantenha os logs</strong> para monitoramento</li>";
echo "<li><strong>Documente</strong> quais arquivos foram removidos</li>";
echo "<li><strong>Verifique dependências</strong> antes de remover arquivos TCPDF</li>";
echo "</ol>";

echo "<h2>📊 Estatísticas Finais</h2>";
echo "<ul>";
echo "<li>Arquivos essenciais: " . count($arquivos_essenciais) . "</li>";
echo "<li>Arquivos para remoção: " . count($arquivos_para_remover) . "</li>";
echo "<li>Arquivos TCPDF para remoção: " . count($arquivos_tcpdf_para_remover) . "</li>";
echo "<li>Espaço potencial para liberar: " . number_format($espaco_total / 1024 / 1024, 2) . " MB</li>";
echo "</ul>";

echo "<hr>";
echo "<p><strong>Data da análise:</strong> " . date('d/m/Y H:i:s') . "</p>";
echo "<p><strong>Sistema:</strong> CadFiscais - IDH</p>";
?> 