<?php
require_once '../config.php';

echo "<h1>🔧 Verificar e Corrigir Tabela de Pagamentos</h1>";

$db = getDB();
if (!$db) {
    echo "❌ Erro na conexão com banco<br>";
    exit;
}

try {
    // Verificar se a tabela existe
    $stmt = $db->query("SHOW TABLES LIKE 'pagamentos'");
    $tabela_existe = $stmt->rowCount() > 0;
    
    if (!$tabela_existe) {
        echo "📋 Criando tabela pagamentos...<br>";
        
        $sql = "
        CREATE TABLE pagamentos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            concurso_id INT NOT NULL,
            fiscal_id INT NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            forma_pagamento ENUM('dinheiro', 'pix', 'transferencia', 'cheque') DEFAULT 'dinheiro',
            data_pagamento DATE NOT NULL,
            observacoes TEXT NULL,
            status_pagamento ENUM('pendente', 'pago', 'cancelado') DEFAULT 'pendente',
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_concurso_id (concurso_id),
            INDEX idx_fiscal_id (fiscal_id),
            INDEX idx_status (status_pagamento),
            INDEX idx_data_pagamento (data_pagamento),
            FOREIGN KEY (concurso_id) REFERENCES concursos(id) ON DELETE CASCADE,
            FOREIGN KEY (fiscal_id) REFERENCES fiscais(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ";
        
        $db->exec($sql);
        echo "✅ Tabela pagamentos criada com sucesso!<br>";
    } else {
        echo "✅ Tabela pagamentos já existe<br>";
        
        // Verificar estrutura da tabela
        $stmt = $db->query("DESCRIBE pagamentos");
        $colunas = $stmt->fetchAll();
        
        echo "<h3>Estrutura atual da tabela:</h3>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f0f0f0;'>";
        echo "<th>Coluna</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th><th>Extra</th>";
        echo "</tr>";
        
        foreach ($colunas as $coluna) {
            echo "<tr>";
            echo "<td>{$coluna['Field']}</td>";
            echo "<td>{$coluna['Type']}</td>";
            echo "<td>{$coluna['Null']}</td>";
            echo "<td>{$coluna['Key']}</td>";
            echo "<td>{$coluna['Default']}</td>";
            echo "<td>{$coluna['Extra']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Verificar se precisa adicionar colunas
        $colunas_existentes = array_column($colunas, 'Field');
        
        if (!in_array('concurso_id', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna concurso_id...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN concurso_id INT NOT NULL AFTER id");
            $db->exec("ALTER TABLE pagamentos ADD INDEX idx_concurso_id (concurso_id)");
            echo "✅ Coluna concurso_id adicionada<br>";
        }
        
        if (!in_array('valor', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna valor...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN valor DECIMAL(10,2) NOT NULL AFTER fiscal_id");
            echo "✅ Coluna valor adicionada<br>";
        }
        
        if (!in_array('forma_pagamento', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna forma_pagamento...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN forma_pagamento ENUM('dinheiro', 'pix', 'transferencia', 'cheque') DEFAULT 'dinheiro' AFTER valor");
            echo "✅ Coluna forma_pagamento adicionada<br>";
        }
        
        if (!in_array('data_pagamento', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna data_pagamento...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN data_pagamento DATE NOT NULL AFTER forma_pagamento");
            echo "✅ Coluna data_pagamento adicionada<br>";
        }
        
        if (!in_array('observacoes', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna observacoes...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN observacoes TEXT NULL AFTER data_pagamento");
            echo "✅ Coluna observacoes adicionada<br>";
        }
        
        if (!in_array('status_pagamento', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna status_pagamento...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN status_pagamento ENUM('pendente', 'pago', 'cancelado') DEFAULT 'pendente' AFTER observacoes");
            echo "✅ Coluna status_pagamento adicionada<br>";
        }
        
        if (!in_array('data_criacao', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna data_criacao...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER status_pagamento");
            echo "✅ Coluna data_criacao adicionada<br>";
        }
        
        if (!in_array('updated_at', $colunas_existentes)) {
            echo "<br>📝 Adicionando coluna updated_at...<br>";
            $db->exec("ALTER TABLE pagamentos ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER data_criacao");
            echo "✅ Coluna updated_at adicionada<br>";
        }
    }
    
    // Verificar se existem dados de teste
    $stmt = $db->query("SELECT COUNT(*) as total FROM pagamentos");
    $total = $stmt->fetch()['total'];
    
    echo "<br><h3>📊 Estatísticas:</h3>";
    echo "Total de pagamentos: $total<br>";
    
    if ($total == 0) {
        echo "<br>💡 Dica: A tabela está vazia. Você pode criar pagamentos através do sistema administrativo.<br>";
    }
    
    echo "<br>✅ Verificação da tabela pagamentos concluída!<br>";
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}
?> 