<?php
require_once '../config.php';

// Verificar se é admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$db = getDB();

try {
    // Simular o que o JavaScript está enviando
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        // Se não há input JSON, usar dados de teste
        $input = ['escola_id' => 1];
    }
    
    $escola_id = isset($input['escola_id']) ? (int)$input['escola_id'] : 0;
    
    if (!$escola_id) {
        throw new Exception('ID da escola não informado');
    }
    
    $sql = "SELECT * FROM escolas WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$escola_id]);
    $escola = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$escola) {
        throw new Exception('Escola não encontrada');
    }
    
    echo json_encode([
        'success' => true,
        'escola' => $escola
    ]);
    
} catch (Exception $e) {
    logActivity('Erro ao buscar escola: ' . $e->getMessage(), 'ERROR');
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?> 