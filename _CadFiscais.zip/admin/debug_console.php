<!DOCTYPE html>
<html>
<head>
    <title>Debug Console</title>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <h1>Debug Console</h1>
    <button onclick="testarShowMessage()">Testar ShowMessage</button>
    <button onclick="testarBuscarEscola()">Testar Buscar Escola</button>
    <div id="resultado"></div>

    <script>
    function showMessage(message, type = 'success') {
        console.log('showMessage chamada:', message, type);
        try {
            Swal.fire({
                title: type === 'success' ? 'Sucesso!' : 'Atenção!',
                text: message,
                icon: type,
                timer: type === 'success' ? 3000 : undefined,
                timerProgressBar: type === 'success'
            });
        } catch (error) {
            console.error('Erro no showMessage:', error);
            alert('Erro no showMessage: ' + error.message);
        }
    }

    function testarShowMessage() {
        console.log('Testando showMessage');
        showMessage('Teste de mensagem', 'success');
    }

    function testarBuscarEscola() {
        console.log('Testando busca de escola');
        
        fetch('buscar_escola.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                escola_id: 1
            })
        })
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Dados recebidos:', data);
            $('#resultado').html('<pre>' + JSON.stringify(data, null, 2) + '</pre>');
            
            if (data.success) {
                showMessage('Escola encontrada!', 'success');
            } else {
                showMessage('Erro: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
            $('#resultado').html('Erro: ' + error.message);
            showMessage('Erro na requisição: ' + error.message, 'error');
        });
    }

    // Capturar erros globais
    window.onerror = function(msg, url, lineNo, columnNo, error) {
        console.error('Erro global:', msg, 'em', url, 'linha', lineNo);
        $('#resultado').html('Erro global: ' + msg);
        return false;
    };

    // Capturar promessas rejeitadas
    window.addEventListener('unhandledrejection', function(event) {
        console.error('Promessa rejeitada:', event.reason);
        $('#resultado').html('Promessa rejeitada: ' + event.reason);
    });
    </script>
</body>
</html> 