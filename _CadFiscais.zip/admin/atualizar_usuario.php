<?php
require_once '../config.php';

// Verificar se é admin
if (!isLoggedIn() || !isAdmin()) {
    redirect('../login.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('usuarios.php');
}

$db = getDB();

try {
    // Validar dados
    $id = (int)($_POST['id'] ?? 0);
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cpf = preg_replace('/\D/', '', $_POST['cpf'] ?? '');
    $tipo_usuario_id = (int)($_POST['tipo_usuario_id'] ?? 0);
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    $status = $_POST['status'] ?? 'ativo';
    
    // Validações
    if ($id <= 0) {
        throw new Exception('ID do usuário inválido');
    }
    
    if (empty($nome)) {
        throw new Exception('Nome é obrigatório');
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido');
    }
    
    if (strlen($cpf) !== 11) {
        throw new Exception('CPF inválido');
    }
    
    if ($tipo_usuario_id <= 0) {
        throw new Exception('Tipo de usuário é obrigatório');
    }
    
    // Verificar se usuário existe
    $stmt = $db->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        throw new Exception('Usuário não encontrado');
    }
    
    // Verificar se email já existe (exceto o próprio usuário)
    $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
    $stmt->execute([$email, $id]);
    if ($stmt->fetch()) {
        throw new Exception('Email já cadastrado');
    }
    
    // Verificar se CPF já existe (exceto o próprio usuário)
    $stmt = $db->prepare("SELECT id FROM usuarios WHERE cpf = ? AND id != ?");
    $stmt->execute([$cpf, $id]);
    if ($stmt->fetch()) {
        throw new Exception('CPF já cadastrado');
    }
    
    // Verificar se tipo de usuário existe
    $stmt = $db->prepare("SELECT id FROM tipos_usuario WHERE id = ?");
    $stmt->execute([$tipo_usuario_id]);
    if (!$stmt->fetch()) {
        throw new Exception('Tipo de usuário inválido');
    }
    
    // Validar senha se fornecida
    if ($senha || $confirmar_senha) {
        if ($senha !== $confirmar_senha) {
            throw new Exception('Senhas não coincidem');
        }
        
        if (strlen($senha) < 6) {
            throw new Exception('Senha deve ter pelo menos 6 caracteres');
        }
    }
    
    // Atualizar usuário
    if ($senha) {
        // Com nova senha
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $db->prepare("
            UPDATE usuarios 
            SET nome = ?, email = ?, cpf = ?, tipo_usuario_id = ?, senha = ?, status = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$nome, $email, $cpf, $tipo_usuario_id, $senha_hash, $status, $id]);
    } else {
        // Sem alterar senha
        $stmt = $db->prepare("
            UPDATE usuarios 
            SET nome = ?, email = ?, cpf = ?, tipo_usuario_id = ?, status = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$nome, $email, $cpf, $tipo_usuario_id, $status, $id]);
    }
    
    // Log da atividade
    logActivity("Usuário atualizado: $nome ($email)", 'INFO');
    
    // Redirecionar com mensagem de sucesso
    setMessage('Usuário atualizado com sucesso!', 'success');
    redirect('usuarios.php');
    
} catch (Exception $e) {
    // Redirecionar com mensagem de erro
    setMessage('Erro ao atualizar usuário: ' . $e->getMessage(), 'error');
    logActivity('Erro ao atualizar usuário: ' . $e->getMessage(), 'ERROR');
    redirect('editar_usuario.php?id=' . $id);
}
?> 