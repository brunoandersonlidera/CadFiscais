<?php
require_once '../config.php';

// Verificar se é admin
if (!isAdmin()) {
    redirect('../login.php');
}

$fiscal_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$db = getDB();

echo "<h1>🔧 Debug - Alocação de Fiscais</h1>";
echo "<p>Fiscal ID: $fiscal_id</p>";

// 1. Verificar se o fiscal existe
echo "<h2>1. Verificação do Fiscal</h2>";
try {
    $stmt = $db->prepare("SELECT * FROM fiscais WHERE id = ?");
    $stmt->execute([$fiscal_id]);
    $fiscal = $stmt->fetch();
    
    if ($fiscal) {
        echo "✅ Fiscal encontrado: " . htmlspecialchars($fiscal['nome']) . "<br>";
        echo "Status: " . $fiscal['status'] . "<br>";
    } else {
        echo "❌ Fiscal não encontrado<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao buscar fiscal: " . $e->getMessage() . "<br>";
}

// 2. Verificar se a tabela alocacoes_fiscais existe
echo "<h2>2. Verificação da Tabela alocacoes_fiscais</h2>";
try {
    $stmt = $db->query("SHOW TABLES LIKE 'alocacoes_fiscais'");
    $tabela_existe = $stmt->rowCount() > 0;
    
    if ($tabela_existe) {
        echo "✅ Tabela alocacoes_fiscais existe<br>";
        
        // Verificar estrutura
        $stmt = $db->query("DESCRIBE alocacoes_fiscais");
        $colunas = $stmt->fetchAll();
        echo "Colunas: ";
        foreach ($colunas as $coluna) {
            echo $coluna['Field'] . ", ";
        }
        echo "<br>";
    } else {
        echo "❌ Tabela alocacoes_fiscais não existe<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar tabela: " . $e->getMessage() . "<br>";
}

// 3. Verificar escolas
echo "<h2>3. Verificação de Escolas</h2>";
try {
    $stmt = $db->query("SELECT COUNT(*) as total FROM escolas WHERE status = 'ativo'");
    $result = $stmt->fetch();
    echo "Escolas ativas: " . $result['total'] . "<br>";
    
    if ($result['total'] > 0) {
        $stmt = $db->query("SELECT id, nome FROM escolas WHERE status = 'ativo' LIMIT 5");
        $escolas = $stmt->fetchAll();
        echo "Primeiras escolas:<br>";
        foreach ($escolas as $escola) {
            echo "- " . htmlspecialchars($escola['nome']) . " (ID: {$escola['id']})<br>";
        }
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar escolas: " . $e->getMessage() . "<br>";
}

// 4. Verificar salas
echo "<h2>4. Verificação de Salas</h2>";
try {
    $stmt = $db->query("SELECT COUNT(*) as total FROM salas WHERE status = 'ativo'");
    $result = $stmt->fetch();
    echo "Salas ativas: " . $result['total'] . "<br>";
    
    if ($result['total'] > 0) {
        $stmt = $db->query("SELECT id, nome, escola_id FROM salas WHERE status = 'ativo' LIMIT 5");
        $salas = $stmt->fetchAll();
        echo "Primeiras salas:<br>";
        foreach ($salas as $sala) {
            echo "- " . htmlspecialchars($sala['nome']) . " (Escola ID: {$sala['escola_id']})<br>";
        }
    }
} catch (Exception $e) {
    echo "❌ Erro ao verificar salas: " . $e->getMessage() . "<br>";
}

// 5. Testar inserção de alocação
echo "<h2>5. Teste de Inserção de Alocação</h2>";
try {
    // Buscar primeira escola e sala
    $stmt = $db->query("SELECT id FROM escolas WHERE status = 'ativo' LIMIT 1");
    $escola = $stmt->fetch();
    
    $stmt = $db->query("SELECT id FROM salas WHERE status = 'ativo' LIMIT 1");
    $sala = $stmt->fetch();
    
    if ($escola && $sala) {
        echo "Testando inserção com Escola ID: {$escola['id']}, Sala ID: {$sala['id']}<br>";
        
        $stmt = $db->prepare("
            INSERT INTO alocacoes_fiscais (
                fiscal_id, escola_id, sala_id, tipo_alocacao, observacoes, 
                data_alocacao, horario_alocacao, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo', CURRENT_TIMESTAMP)
        ");
        
        $resultado = $stmt->execute([
            $fiscal_id, 
            $escola['id'], 
            $sala['id'], 
            'sala', 
            'Teste de debug', 
            date('Y-m-d'), 
            '08:00:00'
        ]);
        
        if ($resultado) {
            $alocacao_id = $db->lastInsertId();
            echo "✅ Inserção de teste bem-sucedida! ID: $alocacao_id<br>";
            
            // Remover o teste
            $stmt = $db->prepare("DELETE FROM alocacoes_fiscais WHERE id = ?");
            $stmt->execute([$alocacao_id]);
            echo "✅ Registro de teste removido<br>";
        } else {
            echo "❌ Erro na inserção de teste<br>";
        }
    } else {
        echo "❌ Não há escolas ou salas disponíveis para teste<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro no teste de inserção: " . $e->getMessage() . "<br>";
}

// 6. Verificar JavaScript
echo "<h2>6. Teste de JavaScript</h2>";
echo "<script>";
echo "console.log('Teste de JavaScript');";
echo "if (typeof showMessage === 'function') {";
echo "    console.log('✅ Função showMessage existe');";
echo "} else {";
echo "    console.log('❌ Função showMessage não existe');";
echo "}";
echo "if (typeof showLoading === 'function') {";
echo "    console.log('✅ Função showLoading existe');";
echo "} else {";
echo "    console.log('❌ Função showLoading não existe');";
echo "}";
echo "if (typeof hideLoading === 'function') {";
echo "    console.log('✅ Função hideLoading existe');";
echo "} else {";
echo "    console.log('❌ Função hideLoading não existe');";
echo "}";
echo "</script>";

// 7. Testar fetch
echo "<h2>7. Teste de Fetch</h2>";
echo "<script>";
echo "fetch('salvar_alocacao.php', {";
echo "    method: 'POST',";
echo "    headers: {";
echo "        'Content-Type': 'application/json',";
echo "    },";
echo "    body: JSON.stringify({";
echo "        fiscal_id: $fiscal_id,";
echo "        escola_id: 1,";
echo "        sala_id: 1,";
echo "        tipo_alocacao: 'sala',";
echo "        observacoes_alocacao: 'Teste via fetch',";
echo "        data_alocacao: '" . date('Y-m-d') . "',";
echo "        horario_alocacao: '08:00'";
echo "    })";
echo "})";
echo ".then(response => {";
echo "    console.log('Response status:', response.status);";
echo "    return response.json();";
echo "})";
echo ".then(data => {";
echo "    console.log('Response data:', data);";
echo "})";
echo ".catch(error => {";
echo "    console.log('Fetch error:', error);";
echo "});";
echo "</script>";

echo "<h2>8. Links de Teste</h2>";
echo "<a href='alocar_fiscal.php?id=$fiscal_id' class='btn btn-primary'>Ir para Alocação</a> ";
echo "<a href='fiscais.php' class='btn btn-secondary'>Voltar para Fiscais</a>";

echo "<h2>9. Console do Navegador</h2>";
echo "<p>Abra o console do navegador (F12) para ver os logs de JavaScript.</p>";

echo "<h2>10. Recomendações</h2>";
echo "<ul>";
echo "<li>Verifique se todas as tabelas foram criadas corretamente</li>";
echo "<li>Confirme se há escolas e salas cadastradas</li>";
echo "<li>Verifique o console do navegador para erros JavaScript</li>";
echo "<li>Teste a conexão com o banco de dados</li>";
echo "</ul>";
?> 