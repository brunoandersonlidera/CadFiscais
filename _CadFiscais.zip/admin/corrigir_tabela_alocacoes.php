<?php
require_once '../config.php';

echo "<h1>🔧 Correção da Tabela alocacoes_fiscais</h1>";

$db = getDB();
if (!$db) {
    echo "❌ Erro na conexão com banco<br>";
    exit;
}

try {
    echo "<h2>1. Verificando estrutura atual</h2>";
    
    $stmt = $db->query("DESCRIBE alocacoes_fiscais");
    $colunas = $stmt->fetchAll();
    
    echo "Colunas atuais:<br>";
    foreach ($colunas as $coluna) {
        echo "- {$coluna['Field']} ({$coluna['Type']})<br>";
    }
    
    // Verificar se há colunas extras
    $colunas_esperadas = [
        'id', 'fiscal_id', 'escola_id', 'sala_id', 'tipo_alocacao', 
        'observacoes', 'data_alocacao', 'horario_alocacao', 'status', 
        'created_at', 'updated_at'
    ];
    
    $colunas_atuais = array_column($colunas, 'Field');
    $colunas_extras = array_diff($colunas_atuais, $colunas_esperadas);
    
    if (!empty($colunas_extras)) {
        echo "<h2>2. Removendo colunas extras</h2>";
        
        foreach ($colunas_extras as $coluna) {
            echo "Removendo coluna: $coluna<br>";
            $db->exec("ALTER TABLE alocacoes_fiscais DROP COLUMN $coluna");
        }
        
        echo "✅ Colunas extras removidas<br>";
    } else {
        echo "✅ Estrutura correta<br>";
    }
    
    // Verificar se faltam colunas
    $colunas_faltantes = array_diff($colunas_esperadas, $colunas_atuais);
    
    if (!empty($colunas_faltantes)) {
        echo "<h2>3. Adicionando colunas faltantes</h2>";
        
        foreach ($colunas_faltantes as $coluna) {
            echo "Adicionando coluna: $coluna<br>";
            
            switch ($coluna) {
                case 'observacoes':
                    $db->exec("ALTER TABLE alocacoes_fiscais ADD COLUMN observacoes TEXT NULL");
                    break;
                case 'data_alocacao':
                    $db->exec("ALTER TABLE alocacoes_fiscais ADD COLUMN data_alocacao DATE NOT NULL");
                    break;
                case 'horario_alocacao':
                    $db->exec("ALTER TABLE alocacoes_fiscais ADD COLUMN horario_alocacao TIME NOT NULL");
                    break;
                case 'updated_at':
                    $db->exec("ALTER TABLE alocacoes_fiscais ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
                    break;
            }
        }
        
        echo "✅ Colunas faltantes adicionadas<br>";
    }
    
    // Verificar índices
    echo "<h2>4. Verificando índices</h2>";
    
    $stmt = $db->query("SHOW INDEX FROM alocacoes_fiscais");
    $indices = $stmt->fetchAll();
    
    $indices_esperados = ['idx_fiscal_id', 'idx_escola_id', 'idx_sala_id', 'idx_data_horario', 'idx_status'];
    $indices_atuais = array_unique(array_column($indices, 'Key_name'));
    
    foreach ($indices_esperados as $indice) {
        if (!in_array($indice, $indices_atuais)) {
            echo "Criando índice: $indice<br>";
            
            switch ($indice) {
                case 'idx_fiscal_id':
                    $db->exec("CREATE INDEX idx_fiscal_id ON alocacoes_fiscais (fiscal_id)");
                    break;
                case 'idx_escola_id':
                    $db->exec("CREATE INDEX idx_escola_id ON alocacoes_fiscais (escola_id)");
                    break;
                case 'idx_sala_id':
                    $db->exec("CREATE INDEX idx_sala_id ON alocacoes_fiscais (sala_id)");
                    break;
                case 'idx_data_horario':
                    $db->exec("CREATE INDEX idx_data_horario ON alocacoes_fiscais (data_alocacao, horario_alocacao)");
                    break;
                case 'idx_status':
                    $db->exec("CREATE INDEX idx_status ON alocacoes_fiscais (status)");
                    break;
            }
        }
    }
    
    echo "✅ Índices verificados<br>";
    
    // Verificar estrutura final
    echo "<h2>5. Estrutura final</h2>";
    
    $stmt = $db->query("DESCRIBE alocacoes_fiscais");
    $colunas_finais = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background-color: #f0f0f0;'>";
    echo "<th>Coluna</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th><th>Extra</th>";
    echo "</tr>";
    
    foreach ($colunas_finais as $coluna) {
        echo "<tr>";
        echo "<td>" . $coluna['Field'] . "</td>";
        echo "<td>" . $coluna['Type'] . "</td>";
        echo "<td>" . $coluna['Null'] . "</td>";
        echo "<td>" . $coluna['Key'] . "</td>";
        echo "<td>" . ($coluna['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . ($coluna['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h2>✅ Correção Concluída!</h2>";
    echo "<p>A tabela alocacoes_fiscais foi corrigida com sucesso.</p>";
    
    echo "<h3>🔧 Próximos Passos</h3>";
    echo "<a href='alocar_fiscal.php?id=6' class='btn btn-primary'>Testar Alocação</a> ";
    echo "<a href='fiscais.php' class='btn btn-secondary'>Voltar para Fiscais</a>";
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
}
?> 